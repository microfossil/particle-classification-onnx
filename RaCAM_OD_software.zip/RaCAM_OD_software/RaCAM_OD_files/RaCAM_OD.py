#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Nov  6 21:27:11 2025

@author: Martin Tetard
"""

import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
from tkinter import filedialog
from tkinter import simpledialog
from tkinter import font
from PIL import ImageTk, Image
import subprocess
import os
import shutil
import csv
from ultralytics import YOLO

import ast
import cv2
import time
import numpy as np
import onnxruntime as ort
from picamera2 import Picamera2
import libcamera


class MyGUI:

    def __init__(self):
        
        def choose_saving_folder():
            self.savingfolder_path = filedialog.askdirectory(title="Select a folder")
            if self.savingfolder_path:
                self.savingfolder.config(text=self.savingfolder_path)
            else:
                self.savingfolder_path = "/home/{username}/Desktop"
                self.savingfolder.config(text=self.savingfolder_path)
                
                
        def choose_model():
            self.model_name_path = filedialog.askopenfilename(title="Select an .onnx file")
            if self.model_name_path:
                self.model_name = self.model_name_path.split("/")[-1]
                self.model_button.config(text=self.model_name)
            else:
                self.model_name = "No .onnx model selected"
                self.model_button.config(text=self.model_name)


        script_folder = os.path.dirname(os.path.abspath(__file__))
        username_folder = f"{script_folder}/.user"
        username_file = f"{username_folder}/user_name.txt"
        if os.path.exists(username_file):
            with open(username_file, "r") as file:
                username = file.read().strip()
        else:
            if os.path.exists(username_folder):
                username = simpledialog.askstring(title="Username Required", prompt="What is your <user> name? (/home/<user>/Desktop). You only have to fill this once:")
                with open(username_file, "w") as file:
                    file.write(username)
            else:
                username = simpledialog.askstring(title="Username Required", prompt="What is your <user> name? (/home/<user>/Desktop). You only have to fill this once:")
                os.mkdir(username_folder)
                with open(username_file, "w") as file:
                    file.write(username)

        self.root = tk.Tk()
        self.root.resizable(False, False)

        policecolour = "#f0eded"
        backgroundcolour = "#43404a"
        backgroundboxcolour = "#bfbfbf"
        buttoncolour = backgroundcolour
        activebuttoncolour = "#1c1c1c"
        buttonpolice = "#fa3e3e"
        activebuttonpolice = "#ff2929"

        self.root.configure(bg=backgroundcolour)

        style= ttk.Style()
        style.configure("TCombobox", fieldbackground= "#bfbfbf", background= "#bfbfbf")

        self.menubar = tk.Menu(self.root, bg=backgroundcolour, fg=policecolour, activebackground=activebuttoncolour, activeforeground=policecolour)

        self.filemenu = tk.Menu(self.menubar, tearoff=0)
        self.filemenu.add_command(label="Image acquisition", command=self.show_messageacquisition)
        self.filemenu.add_command(label="Object detection", command=self.show_messagerecognition)
        self.filemenu.add_command(label="Show annotated images", command=self.show_messageFOV)
        self.filemenu.add_command(label="Select saving folder", command=self.show_messagesaving)
        self.filemenu.add_command(label="Select .onnx model", command=self.show_messagemodel)
        self.filemenu.add_command(label="Confidence threshold", command=self.show_messagethreshold)
        self.filemenu.add_command(label="Core name", command=self.show_messagecore)
        self.filemenu.add_command(label="Sample name", command=self.show_messagesample)
        self.filemenu.add_command(label="Magnification", command=self.show_messagemagnification)
        self.filemenu.add_command(label="Brightness", command=self.show_messagebrightness)
        self.filemenu.add_command(label="Constrast", command=self.show_messagecontrast)
        self.filemenu.add_command(label="Exposure time", command=self.show_messageexposure)
        self.filemenu.add_command(label="Image rotation", command=self.show_messagerotation)
        self.filemenu.add_command(label="Original image quality", command=self.show_messagequality)
        self.filemenu.add_command(label="Image type", command=self.show_messagesaturation)
        self.filemenu.add_command(label="Live preview", command=self.show_messageliveinfo)
        self.filemenu.add_command(label="Live preview detection", command=self.show_messagelivescanner)
        self.filemenu.add_command(label="Snapshot", command=self.show_messagesnapinfo)
        self.filemenu.add_command(label="Batch processing", command=self.show_messagebatch)
        self.filemenu.add_command(label="Generate census data", command=self.show_messagecensus)

        self.filemenu2 = tk.Menu(self.menubar, tearoff=0)
        self.filemenu2.add_command(label="Software", command=self.show_messagesoftware)
        self.filemenu2.add_command(label="Developers", command=self.show_messagedev)

        self.menubar.add_cascade(menu=self.filemenu, label="Instructions")
        self.menubar.add_cascade(menu=self.filemenu2, label="About")

        self.root.config(menu=self.menubar)

        WindowWidth = 660
        WindowHeight = 640

        self.root.geometry(f"{WindowWidth}x{WindowHeight}")

        self.root.title("RaCAM_OD")

        self.firstframe = tk.Frame(self.root)
        self.firstframe.configure(bg=backgroundcolour)
        self.firstframe.columnconfigure(0, weight=1)
        self.firstframe.columnconfigure(1, weight=1)

        self.esnzlogo = Image.open(f"/home/{username}/Desktop/RaCAM_OD_files/.logo/ESNZlogo.png")
        self.esnzlogo = ImageTk.PhotoImage(self.esnzlogo)
        
        self.racamlogo = Image.open(f"/home/{username}/Desktop/RaCAM_OD_files/.logo/LogoRaCAMOD.png")
        self.racamlogo = ImageTk.PhotoImage(self.racamlogo)

        self.label = tk.Label(self.firstframe, text="RaCAM_OD software v3.1: Object detection workflow", font=('Arial', 18), bg=backgroundcolour, fg=policecolour)
        self.label.grid(row=0, column=0, columnspan=2)
        
        self.labelracam = tk.Label(self.firstframe, image=self.racamlogo, bg=backgroundcolour)
        self.labelracam.grid(row=1, column=0, sticky="w", padx=10, pady=10)

        self.labelesnz = tk.Label(self.firstframe, image=self.esnzlogo, bg=backgroundcolour)
        self.labelesnz.grid(row=1, column=1, sticky="e", padx=10, pady=10)

        self.firstframe.pack(fill='x')


        self.boxframe = tk.Frame(self.root)
        self.boxframe.configure(bg=backgroundcolour)
        self.boxframe.columnconfigure(0, weight=1)
        self.boxframe.columnconfigure(1, weight=1)
        self.boxframe.columnconfigure(2, weight=1)
        
        self.imageacquisitionlabel = tk.Label(self.boxframe, text="Image acquisition", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.imageacquisitionlabel.grid(row=0, column=0, sticky=tk.W+tk.E, pady=5)

        self.checkacquisitionframe = tk.Frame(self.boxframe)
        self.checkacquisitionframe.configure(bg=backgroundcolour)
        self.checkacquisitionframe.columnconfigure(0, weight=1)
        self.checkacquisitionframe.columnconfigure(1, weight=1)

        self.imageacquisitiondefault = "yes" #put back on "no"
        self.imageacquisition = tk.StringVar(self.boxframe, self.imageacquisitiondefault)

        self.imageacquisition_variable = tk.IntVar()
        self.imageacquisition_variable.set(1) #put back on "2"

        self.imageacquisitionyes = tk.Radiobutton(self.checkacquisitionframe, text="Yes", selectcolor=backgroundcolour, bg=backgroundcolour, fg=policecolour, activebackground=activebuttoncolour, activeforeground=activebuttonpolice, variable=self.imageacquisition_variable, value=1, command=self.show_messageimageacqyes)
        self.imageacquisitionyes.grid(row=1, column=0, sticky=tk.W+tk.E)

        self.imageacquisitionno = tk.Radiobutton(self.checkacquisitionframe, text="No", selectcolor=backgroundcolour, bg=backgroundcolour, fg=policecolour, activebackground=activebuttoncolour, activeforeground=activebuttonpolice, variable=self.imageacquisition_variable, value=2, command=self.show_messageimageacqno)
        self.imageacquisitionno.grid(row=1, column=1, sticky=tk.W+tk.E)

        self.checkacquisitionframe.grid(row=1, column=0, sticky=tk.W+tk.E)


        self.imagerecognitionlabel = tk.Label(self.boxframe, text="Object detection", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.imagerecognitionlabel.grid(row=0, column=1, sticky=tk.W+tk.E, pady=5)

        self.checkimagerecognitionframe = tk.Frame(self.boxframe)
        self.checkimagerecognitionframe.configure(bg=backgroundcolour)
        self.checkimagerecognitionframe.columnconfigure(0, weight=1)
        self.checkimagerecognitionframe.columnconfigure(1, weight=1)

        self.imagerecognitiondefault = "no"
        self.imagerecognition = tk.StringVar(self.boxframe, self.imagerecognitiondefault)

        self.imagerecognition_variable = tk.IntVar()
        self.imagerecognition_variable.set(2)

        self.imagerecognitionyes = tk.Radiobutton(self.checkimagerecognitionframe, text="Yes", selectcolor=backgroundcolour, bg=backgroundcolour, fg=policecolour, activebackground=activebuttoncolour, activeforeground=activebuttonpolice, variable=self.imagerecognition_variable, value=1, command=self.show_messageimagerecogyes)
        self.imagerecognitionyes.grid(row=1, column=0, sticky=tk.W+tk.E)

        self.imagerecognitionno = tk.Radiobutton(self.checkimagerecognitionframe, text="No", selectcolor=backgroundcolour, bg=backgroundcolour, fg=policecolour, activebackground=activebuttoncolour, activeforeground=activebuttonpolice, variable=self.imagerecognition_variable, value=2, command=self.show_messageimagerecogno)
        self.imagerecognitionno.grid(row=1, column=1, sticky=tk.W+tk.E)

        self.checkimagerecognitionframe.grid(row=1, column=1, sticky=tk.W+tk.E)
        

        self.imageFOVlabel = tk.Label(self.boxframe, text="Show annotated images", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.imageFOVlabel.grid(row=0, column=2, sticky=tk.W+tk.E, pady=5)

        self.checkFOVframe = tk.Frame(self.boxframe)
        self.checkFOVframe.configure(bg=backgroundcolour)
        self.checkFOVframe.columnconfigure(0, weight=1)
        self.checkFOVframe.columnconfigure(1, weight=1)

        self.imageFOVdefault = "no"
        self.imageFOV = tk.StringVar(self.boxframe, self.imageFOVdefault)

        self.imageFOV_variable = tk.IntVar()
        self.imageFOV_variable.set(2)

        self.imageFOVyes = tk.Radiobutton(self.checkFOVframe, text="Yes", selectcolor=backgroundcolour, bg=backgroundcolour, fg=policecolour, activebackground=activebuttoncolour, activeforeground=activebuttonpolice, variable=self.imageFOV_variable, value=1, command=self.show_messageimageFOVyes)
        self.imageFOVyes.grid(row=1, column=0, sticky=tk.W+tk.E)

        self.imageFOVno = tk.Radiobutton(self.checkFOVframe, text="No", selectcolor=backgroundcolour, bg=backgroundcolour, fg=policecolour, activebackground=activebuttoncolour, activeforeground=activebuttonpolice, variable=self.imageFOV_variable, value=2, command=self.show_messageimageFOVno)
        self.imageFOVno.grid(row=1, column=1, sticky=tk.W+tk.E)

        self.checkFOVframe.grid(row=1, column=2, sticky=tk.W+tk.E)
        
        
        self.folderlabel = tk.Label(self.boxframe, text="Select saving folder", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.folderlabel.grid(row=2, column=0, sticky=tk.W+tk.E, pady=5)

        self.savingfolder_path = f"/home/{username}/Desktop"
        self.savingfolder = tk.Button(self.boxframe, text=self.savingfolder_path, command=choose_saving_folder, width=1)
        self.savingfolder.grid(row=3, column=0, sticky=tk.W+tk.E)
    
        
        self.modellabel = tk.Label(self.boxframe, text="Select .onnx model", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.modellabel.grid(row=2, column=1, sticky=tk.W+tk.E, pady=5)

        self.model_name = "No .onnx model selected"
        self.model_button = tk.Button(self.boxframe, text=self.model_name, command=choose_model, width=1)
        self.model_button.grid(row=3, column=1, sticky=tk.W+tk.E)
        
        
        self.thresholdlabel = tk.Label(self.boxframe, text="Confidence threshold", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.thresholdlabel.grid(row=2, column=2, sticky=tk.W+tk.E, pady=5)

        self.thresholddefault = tk.IntVar()
        self.thresholddefault.set(0.30)
        self.threshold = tk.Entry(self.boxframe, textvariable=str(self.thresholddefault), bg=backgroundboxcolour)
        self.threshold.grid(row=3, column=2, sticky=tk.W+tk.E)
        
        
        self.corenamelabel = tk.Label(self.boxframe, text="Core name", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.corenamelabel.grid(row=4, column=0, sticky=tk.W+tk.E, pady=5)

        self.corenamedefault = tk.StringVar()
        self.corenamedefault.set("Core_name")
        self.corename = tk.Entry(self.boxframe, textvariable=str(self.corenamedefault), bg=backgroundboxcolour)
        self.corename.grid(row=5, column=0, sticky=tk.W+tk.E)


        self.samplenamelabel = tk.Label(self.boxframe, text="Sample name", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.samplenamelabel.grid(row=4, column=1, sticky=tk.W+tk.E, pady=5)

        self.samplenamedefault = tk.StringVar()
        self.samplenamedefault.set("Sample_name")
        self.samplename = tk.Entry(self.boxframe, textvariable=str(self.samplenamedefault), bg=backgroundboxcolour)
        self.samplename.grid(row=5, column=1, sticky=tk.W+tk.E)


        self.magnificationlabel = tk.Label(self.boxframe, text="Magnification", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.magnificationlabel.grid(row=4, column=2, sticky=tk.W+tk.E, pady=5)

        self.magnificationlist = ["x2.5", "x5", "x10", "x20", "x40", "x63", "x100"]
        self.magnification = ttk.Combobox(self.boxframe, values=self.magnificationlist)
        self.magnification.set("x10")
        self.magnification.grid(row=5, column=2, sticky=tk.W+tk.E)


        self.brightnesslabel = tk.Label(self.boxframe, text="Brightness", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.brightnesslabel.grid(row=6, column=0, sticky=tk.W+tk.E, pady=5)
        
        self.brightnessdefault = tk.IntVar()
        self.brightnessdefault.set(0.05)
        self.brightness = tk.Entry(self.boxframe, textvariable=str(self.brightnessdefault), bg=backgroundboxcolour)
        self.brightness.grid(row=7, column=0, sticky=tk.W+tk.E)
        

        self.contrastlabel = tk.Label(self.boxframe, text="Contrast", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.contrastlabel.grid(row=6, column=1, sticky=tk.W+tk.E, pady=5)

        self.contrastdefault = tk.IntVar()
        self.contrastdefault.set(1.30)
        self.contrast = tk.Entry(self.boxframe, textvariable=str(self.contrastdefault), bg=backgroundboxcolour)
        self.contrast.grid(row=7, column=1, sticky=tk.W+tk.E)


        self.exposurelabel = tk.Label(self.boxframe, text="Exposure time", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.exposurelabel.grid(row=6, column=2, sticky=tk.W+tk.E, pady=5)

        self.exposuredefault = tk.IntVar()
        self.exposuredefault.set(500)
        self.exposure = tk.Entry(self.boxframe, textvariable=str(self.exposuredefault), bg=backgroundboxcolour)
        self.exposure.grid(row=7, column=2, sticky=tk.W+tk.E)


        self.rotationlabel = tk.Label(self.boxframe, text="Image rotation", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.rotationlabel.grid(row=8, column=0, sticky=tk.W+tk.E, pady=5)

        self.rotationlist = ["0", "180"]
        self.rotation = ttk.Combobox(self.boxframe, values=self.rotationlist)
        self.rotation.set(180)
        self.rotation.grid(row=9, column=0, sticky=tk.W+tk.E)


        self.qualitylabel = tk.Label(self.boxframe, text="Original image quality", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.qualitylabel.grid(row=8, column=1, sticky=tk.W+tk.E, pady=5)

        self.qualitydefault = tk.IntVar()
        self.qualitydefault.set(100)
        self.quality = tk.Entry(self.boxframe, textvariable=str(self.qualitydefault), bg=backgroundboxcolour)
        self.quality.grid(row=9, column=1, sticky=tk.W+tk.E)


        self.saturationlabel = tk.Label(self.boxframe, text="Image type", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.saturationlabel.grid(row=8, column=2, sticky=tk.W+tk.E, pady=5)

        self.checkframe = tk.Frame(self.boxframe)
        self.checkframe.configure(bg=backgroundcolour)
        self.checkframe.columnconfigure(0, weight=1)
        self.checkframe.columnconfigure(1, weight=1)

        self.saturationdefault = "0"
        self.saturation = tk.StringVar(self.boxframe, self.saturationdefault)

        self.imagetype_variable = tk.IntVar()
        self.imagetype_variable.set(1)

        self.checkbw = tk.Radiobutton(self.checkframe, text="Greyscale", selectcolor=backgroundcolour, bg=backgroundcolour, fg=policecolour, activebackground=activebuttoncolour, activeforeground=activebuttonpolice, variable=self.imagetype_variable, value=1, command=self.show_messagebw)
        self.checkbw.grid(row=1, column=0, sticky=tk.W+tk.E)

        self.checkcolour = tk.Radiobutton(self.checkframe, text="Colour", selectcolor=backgroundcolour, bg=backgroundcolour, fg=policecolour, activebackground=activebuttoncolour, activeforeground=activebuttonpolice, variable=self.imagetype_variable, value=2, command=self.show_messagecolour)
        self.checkcolour.grid(row=1, column=1, sticky=tk.W+tk.E)

        self.checkframe.grid(row=9, column=2, sticky=tk.W+tk.E)

        self.boxframe.pack(fill='x')


        self.buttonframe = tk.Frame(self.root)
        self.buttonframe.configure(bg=backgroundcolour)
        self.buttonframe.columnconfigure(0, weight=1)
        self.buttonframe.columnconfigure(1, weight=1)
        ButtonWidth = int(WindowWidth/2)

        self.livecolourbutton = tk.Button(self.buttonframe, text="Live preview", font=('Arial', 20, 'bold') , bg=buttoncolour, fg=buttonpolice, activebackground=activebuttoncolour, activeforeground=activebuttonpolice, width=ButtonWidth, command=self.show_messagelive)
        self.livecolourbutton.grid(row=0, column=0, sticky=tk.W+tk.E)

        self.snapcolourbutton = tk.Button(self.buttonframe, text="Snapshot", font=('Arial', 20, 'bold'),  bg=buttoncolour, fg=buttonpolice, activebackground=activebuttoncolour, activeforeground=activebuttonpolice, width=ButtonWidth, command=self.show_messagesnap)
        self.snapcolourbutton.grid(row=0, column=1, sticky=tk.W+tk.E)

        self.batchbutton = tk.Button(self.buttonframe, text="Batch processing", font=('Arial', 16, 'bold') , bg=buttoncolour, fg=buttonpolice, activebackground=activebuttoncolour, activeforeground=activebuttonpolice, width=ButtonWidth, command=self.batch_processing)
        self.batchbutton.grid(row=1, column=0, sticky=tk.W+tk.E)

        self.censusbutton = tk.Button(self.buttonframe, text="Census data", font=('Arial', 16, 'bold') , bg=buttoncolour, fg=buttonpolice, activebackground=activebuttoncolour, activeforeground=activebuttonpolice, width=ButtonWidth, command=self.generate_image_count_csv)
        self.censusbutton.grid(row=1, column=1, sticky=tk.W+tk.E)

        self.buttonframe.pack(fill='x', pady=15)


        self.savebutton = tk.Button(text="Save profile", font=('Arial', 8) , bg=buttoncolour, fg=policecolour, activebackground=activebuttoncolour, activeforeground=policecolour, width=6, command=self.save_profile)
        self.savebutton.pack(side="left", anchor="s", pady=5)
        self.loadbutton = tk.Button(text="Load profile", font=('Arial', 8) , bg=buttoncolour, fg=policecolour, activebackground=activebuttoncolour, activeforeground=policecolour, width=6, command=self.load_profile)
        self.loadbutton.pack(side="left", anchor="s", padx=0, pady=5)

        self.cclogo = Image.open(f"/home/{username}/Desktop/RaCAM_OD_files/.logo/License.png")
        self.cclogo = ImageTk.PhotoImage(self.cclogo)
        self.labelcc = tk.Label(self.root, image=self.cclogo, bg=backgroundcolour)
        self.labelcc.pack(side="right", anchor="s")

        self.credit = tk.Label(self.root, text="This software was developed by Martin Tetard and Earth Sciences New Zealand", font=('Arial', 8), bg=backgroundcolour, fg=policecolour)
        self.credit.pack(side="right", anchor="s")

        self.root.mainloop()


    def show_messageimageacqyes(self):
        self.imageacquisitiondefault = "yes"
        self.imageacquisition = tk.StringVar(self.boxframe, self.imageacquisitiondefault)
        self.livecolourbutton.config(state="normal", text="Live preview")
        self.livecolourbutton.update()


    def show_messageimageacqno(self):
        self.imageacquisitiondefault = "no"
        self.imageacquisition = tk.StringVar(self.boxframe, self.imageacquisitiondefault)
        if self.imagerecognitiondefault == "yes":
            self.livecolourbutton.config(state="normal", text="Live detection")
            self.livecolourbutton.update()

    def show_messageimageFOVyes(self):
        self.imageFOVdefault = "yes"
        self.imageFOV = tk.StringVar(self.boxframe, self.imageFOVdefault)


    def show_messageimageFOVno(self):
        self.imageFOVdefault = "no"
        self.imageFOV = tk.StringVar(self.boxframe, self.imageFOVdefault)


    def show_messageimagerecogyes(self):
        self.imagerecognitiondefault = "yes"
        self.imagerecognition = tk.StringVar(self.boxframe, self.imagerecognitiondefault)
        if self.imageacquisitiondefault == "no":
            self.livecolourbutton.config(state="normal", text="Live detection")
            self.livecolourbutton.update()


    def show_messageimagerecogno(self):
        self.imagerecognitiondefault = "no"
        self.imagerecognition = tk.StringVar(self.boxframe, self.imagerecognitiondefault)
        self.livecolourbutton.config(state="normal", text="Live preview")
        self.livecolourbutton.update()


    def show_messagebw(self):
        self.saturationdefault = "0"
        self.saturation = tk.StringVar(self.boxframe, self.saturationdefault)


    def show_messagecolour(self):
        self.saturationdefault = "1"
        self.saturation = tk.StringVar(self.boxframe, self.saturationdefault)


    def show_messagedev(self):
        messagebox.showinfo(title="About the developers", message="This software has been developed by Martin Tetard at ESNZ (Earth Sciences New Zealand).")


    def show_messagesoftware(self):
        messagebox.showinfo(title="About the software", message="RaCAM_OD software is a free software (developed using the Python programming language), used to perform image acquisition (using rpicam-apps developed by ((C) Raspberry Pi Ltd), and object detection (using an .onnx model software). Copyright (C) 2026 Martin Tetard. This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version. This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. You should have received a copy of the GNU General Public License along with this program (see gpl-3.0.text in the License directory). If not, see https://www.gnu.org/licenses/.")


    def show_messagecore(self):
        messagebox.showinfo(title="Core name information", message="Enter the core identification value, without '"'-'"' or '"'#'"' symbols.")


    def show_messagesample(self):
        messagebox.showinfo(title="Sample name information", message="Enter the sample identification value, without '"'-'"' or '"'#'"' symbols.")


    def show_messagemagnification(self):
        messagebox.showinfo(title="Magnification information", message="Enter the lens magnification vaue used, for example 'x40'.")


    def show_messagebrightness(self):
        messagebox.showinfo(title="Adjust brightness", message="Adjust the image brightness correction value from -1.0 (completely black image), to 1.0 (completely white image). ")


    def show_messagecontrast(self):
        messagebox.showinfo(title="Adjust contrast", message="Adjust the contrast value of the previewed and captured images. Values above 1.0 increase the contrast, and values below 1.0 decrease it.")


    def show_messageexposure(self):
        messagebox.showinfo(title="Adjust exposure time", message="Adjust the sensor exposure time in ms. A higher value allows for more light to come into the camera sensor and increases the image brightness.")


    def show_messagerotation(self):
        messagebox.showinfo(title="Adjust image rotation", message="Adjust the image rotation from 0 degrees to 180  degrees (depending on the camera's orientation).")


    def show_messagequality(self):
        messagebox.showinfo(title="Adjust image quality", message="Adjust the jpeg image quality value in %, from 0 (more compression, more artifacts, less quality) to 100 (no compression, no artifact, best quality, but bigger size on disk).")


    def show_messagesaturation(self):
        messagebox.showinfo(title="Select image type", message="Select image type between greyscale and full colour.")


    def show_messagesaving(self):
        messagebox.showinfo(title="Select a saving folder", message="Select a saving folder path where all images will be saved. Default is Desktop.")


    def show_messageacquisition(self):
        messagebox.showinfo(title="Image acquisition", message="Choose if you want to acquire an original FOV image.")


    def show_messagerecognition(self):
        messagebox.showinfo(title="Object detection", message="Choose if you automatically want to apply object detection on the captured FOV image using a pre-trained and loaded .onnx YOLO model (if 'Image acquisition' is set on 'Yes'), or perform live detection (if 'Image acquisition' is set on 'No').")


    def show_messageFOV(self):
        messagebox.showinfo(title="Show annotated images", message="Choose if you automatically want to show the annotated FOV image.")


    def show_messagemodel(self):
        messagebox.showinfo(title="Select .onnx model", message="Select a YOLO .onnx file you want to use for object detection.")


    def show_messagethreshold(self):
        messagebox.showinfo(title="Adjust confidence threshold", message="Adjust the .onnx model confidence threshold from 0 to 1 under which an object won't be classified.")


    def show_messageliveinfo(self):
        messagebox.showinfo(title="Livefeed preview", message="Shows a preview of the livefeed currently displayed in the camera's field of view by using the adjusment entered in the textboxes")


    def show_messagelivescanner(self):
        messagebox.showinfo(title="Livefeed preview detection", message="Shows a scanning preview of the livefeed using live object detection. To use it, Select 'Image acquisition: No', and 'Object detection: Yes', and select an .onnx model. After clicking, if you write the name of an object (class) you are looking for (exact name learned by the model), an snapshot will be automatically taken everytime the object is detected and saved in the '/RaCAM_OD_output/Image_recognition/' directory.")
  

    def show_messagesnapinfo(self):
        messagebox.showinfo(title="Taking a snapshot", message="Takes and save a snapshot of the camera's field of view by using the adjusments entered into the textboxes. This button will display a fullscreen preview for 5 sec for depth of field adjustment before saving the image in the '/RaCAM_OD_output/Image_acquisition/' directory. If you select 'Object detection: Yes', objects of interest will be recognised on the acquired field of view and will be saved in the '/RaCAM_OD_output/Image_recognition/' directory and census files in the '/RaCAM_OD_output/Raw_census_data/' directory.")


    def show_messagebatch(self):
        messagebox.showinfo(title="Batch processing of existing FOV images", message="Click to automatically batch process existing folders of images. Select and enter a 'core' directory containing 'samples' subdirectories, containing FOV images (by default in the '/RaCAM_OD_output/Image_acquisition/' directory).")


    def show_messagecensus(self):
        messagebox.showinfo(title="Generating a census data csv file", message="Click to generate a summary census data table containing the abundance of each taxa for each sample of the selected core. Select and enter a 'core' directory containing 'samples' subdirectories, containing .txt census counts files (by default in the '/RaCAM_OD_output/Raw_census_data/' directory.")


    def save_profile(self):
        saveprofile = open(f"{self.savingfolder_path}/RaCAM_OD_files/.user/profile.txt","w")
        profile_lst = [self.corename.get(),self.samplename.get(),self.magnification.get(),self.brightness.get(),self.contrast.get(),self.exposure.get(),self.rotation.get(),self.quality.get(),self.threshold.get()]
        saveprofile.write(str(profile_lst))
        saveprofile.close
        
                
    def load_profile(self):
        loadprofile = open(f"{self.savingfolder_path}/RaCAM_OD_files/.user/profile.txt","r")
        loadprofile_list = eval(loadprofile.read())
        loadprofile.close()
        self.corenamedefault.set(loadprofile_list[0])
        self.samplenamedefault.set(loadprofile_list[1])
        self.magnification.set(loadprofile_list[2])
        self.brightnessdefault.set(loadprofile_list[3])
        self.contrastdefault.set(loadprofile_list[4])
        self.exposuredefault.set(loadprofile_list[5])
        self.rotation.set(loadprofile_list[6])
        self.qualitydefault.set(loadprofile_list[7])
        self.thresholddefault.set(loadprofile_list[8])


    def batch_processing(self):
        self.livecolourbutton.config(state="disabled")
        self.livecolourbutton.update()
        self.snapcolourbutton.config(state="disabled")
        self.snapcolourbutton.update()
        self.batchbutton.config(state="disabled", text="Processing...")
        self.batchbutton.update()
        self.censusbutton.config(state="disabled")
        self.censusbutton.update()
        
        if self.imagerecognition.get() == "no":
            messagebox.showinfo(title="Error", message="Image recognition is set on 'No'")
            
        elif self.imagerecognition.get() == "yes":
            if self.model_name == "No .onnx model selected":
                messagebox.showinfo(title="Error", message="No .onnx model was selected. Please select an .onnx model file.")
            else:
                self.image_folder_path = filedialog.askdirectory(title="Select and enter a core folder containing sample folders, containing FOV images.")
                if self.image_folder_path:
                    onnx_model_batch = YOLO(self.model_name_path, task='detect')
                    class_list_batch = [onnx_model_batch.names[i] for i in sorted(onnx_model_batch.names.keys())]
                    onnx_session_for_imgsz_batch = ort.InferenceSession(self.model_name_path)
                    input_shape_model_batch = onnx_session_for_imgsz_batch.get_inputs()[0].shape
                    imgsz_extracted_batch = int(input_shape_model_batch[3:][0])

                    input_dir_batch = self.image_folder_path
                    rel_input_dir = os.path.dirname(input_dir_batch)
                    rel_input_dir_parent = os.path.dirname(rel_input_dir)
                    rel_core_dir = os.path.basename(input_dir_batch)
                    output_dir = f"{rel_input_dir_parent}/Image_recognition/{rel_core_dir}"
                    FOV_image_extensions = (".jpg", ".jpeg", ".png", ".bmp", ".tiff")

                    for root_directory_bis, dirs_bis, data_files_bis in os.walk(input_dir_batch):
                        for file_bis in data_files_bis:
                            if file_bis.lower().endswith(FOV_image_extensions):
                                FOV_image_path = os.path.join(root_directory_bis, file_bis)

                                rel_path = os.path.relpath(FOV_image_path, input_dir_batch)
                                rel_sample_txt_name = os.path.dirname(rel_path)
                                
                                target_folder = os.path.join(output_dir, rel_sample_txt_name)
                                os.makedirs(target_folder, exist_ok=True)

                                original_FOV_name, ext = os.path.splitext(file_bis)
                                output_annotated_name = f"{original_FOV_name}-annotated{ext}"
                                output_annotated_path = os.path.join(target_folder, output_annotated_name)

                                inference_batch = onnx_model_batch(FOV_image_path, imgsz=imgsz_extracted_batch, conf=float(self.threshold.get()), verbose=False)
                                inference_batch[0].save(output_annotated_path)

                                detected_indices_batch = inference_batch[0].boxes.cls.tolist()
                                detected_ints_batch = [int(idx) for idx in detected_indices_batch]
                                detected_classes_batch = [onnx_model_batch.names[idx] for idx in detected_ints_batch]
                                row_counts_batch = [str(detected_classes_batch.count(cls)) for cls in class_list_batch]
                                
                                output_txt_folder_batch = f"{rel_input_dir_parent}/Raw_census_data/{rel_core_dir}/{rel_sample_txt_name}/"
                                if not os.path.isdir(output_txt_folder_batch):
                                    os.makedirs(output_txt_folder_batch)
                                output_txt_file_batch = f"{output_txt_folder_batch}{original_FOV_name}.txt"

                                with open(output_txt_file_batch, "w", encoding="utf-8") as f:
                                    f.write("Core name" + "," + "Sample name" + "," + "Original image name" + "," + ",".join(class_list_batch) + "\n")
                                    f.write(rel_core_dir + "," + rel_sample_txt_name + "," + original_FOV_name + "," + ",".join(row_counts_batch) + "\n")

                    messagebox.showinfo(title="Batch processing", message=f"Batch image recognition successfully completed for {rel_core_dir}.")
                else:
                    self.image_folder_path = "No core folder of FOV images selected"
                    messagebox.showinfo(title="Error", message=self.image_folder_path)
                    
        self.livecolourbutton.config(state="normal")
        self.snapcolourbutton.config(state="normal")
        self.batchbutton.config(state="normal", text="Batch processing")
        self.censusbutton.config(state="normal")


    def generate_image_count_csv(self):
        self.livecolourbutton.config(state="disabled")
        self.livecolourbutton.update()
        self.snapcolourbutton.config(state="disabled")
        self.snapcolourbutton.update()
        self.batchbutton.config(state="disabled")
        self.batchbutton.update()
        self.censusbutton.config(state="disabled", text="Processing...")
        self.censusbutton.update()
        
        self.census_folder_path = filedialog.askdirectory(title="Select and enter a core folder containing sample folders, containing .txt counts files.")
        if self.census_folder_path:
            self.census_directory = self.census_folder_path
            self.core_directory_name = os.path.basename(self.census_directory)
            self.parent_census_directory = os.path.dirname(self.census_directory)
            self.census_ouput = f"{self.parent_census_directory}/{self.core_directory_name}_census_summary.txt"
            summary_census_data = {}
            taxa_headers = None

            for root_directory, dirs, data_files in os.walk(self.census_directory):
                txt_files = [f for f in data_files if f.endswith(".txt")]
                if not txt_files:
                    continue
                sub_dir_name = os.path.basename(root_directory)
                if sub_dir_name not in summary_census_data:
                    summary_census_data[sub_dir_name] = {}
                for taxa_file_name in txt_files:
                    taxa_file_path = os.path.join(root_directory, taxa_file_name)
                    try:
                        with open(taxa_file_path, "r", encoding="utf-8") as f:
                            reader = csv.reader(f)
                            taxa_file_headers = next(reader, None)
                            taxa_file_counts = next(reader, None)
                            if not taxa_file_headers or not taxa_file_counts:
                                continue
                            taxa_file_headers = taxa_file_headers[3:] #Adjust if you want to skip some columns in the future
                            taxa_file_counts = taxa_file_counts[3:] #Adjust if you want to skip some columns in the future
                            if taxa_headers is None:
                                taxa_headers = [h.strip() for h in taxa_file_headers]
                            for species, count_str in zip(taxa_file_headers, taxa_file_counts):
                                species = species.strip()
                                try:
                                    count_val = int(count_str.strip())
                                except ValueError:
                                    count_val = 0
                                summary_census_data[sub_dir_name][species] = (summary_census_data[sub_dir_name].get(species, 0) + count_val)

                    except Exception as e:
                        print(f"Skipping broken file {taxa_file_name} due to: {e}")
            if not taxa_headers or not summary_census_data:
                print("No valid census text files or headers were found. Please check selected directory.")
                return
            with open(self.census_ouput, "w", encoding="utf-8") as out_file:
                census_summary_writer = csv.writer(out_file)
                census_summary_writer.writerow(["Sample"] + taxa_headers)
                for sub_dir_sample in sorted(summary_census_data.keys()):
                    sample_row = [sub_dir_sample]
                    for species in taxa_headers:
                        sample_row.append(summary_census_data[sub_dir_sample].get(species, 0))
                    census_summary_writer.writerow(sample_row)
            print(f"Census data summary file successfully generated at {self.census_ouput} for {self.core_directory_name}.")
            messagebox.showinfo(title="Census data", message=f"Census data summary file succesfully generated for {self.core_directory_name}.")
        else:
            self.census_folder_path = "No core folder of .txt counts files selected"
            messagebox.showinfo(title="Error", message=self.census_folder_path)
            
        self.livecolourbutton.config(state="normal")
        self.snapcolourbutton.config(state="normal")
        self.batchbutton.config(state="normal")
        self.censusbutton.config(state="normal", text="Census data")


    def show_messagelive(self):
        self.livecolourbutton.config(state="disabled", text="Processing...")
        self.livecolourbutton.update()
        self.snapcolourbutton.config(state="disabled")
        self.snapcolourbutton.update()
        self.batchbutton.config(state="disabled")
        self.batchbutton.update()
        self.censusbutton.config(state="disabled")
        self.censusbutton.update()

        if self.imagerecognition.get() == "no":
            subprocess.run(["rpicam-hello", "-t", "0", "--preview", "100,100,1024,768", "--rotation", self.rotation.get(), "--saturation", self.saturation.get(), "--contrast", self.contrast.get(), "--gain", "1", "--brightness", self.brightness.get(), "--shutter", self.exposure.get()])
        elif self.imagerecognition.get() == "yes":
            if self.imageacquisition.get() == "no":
                if self.model_name == "No .onnx model selected":
                    messagebox.showinfo(title="Error", message="No .onnx model was selected. Please select an .onnx model file.")
                else:
                    ask_target_class = simpledialog.askstring("", "Enter a target class name (exact name learned by the model)\nto automatically save snapshots if this class is detected.\n\nLeave blank to use live detection without automated snapshots.\n")
                    
                    if ask_target_class is None:
                        ask_target_class = "Live detection canceled."
                        messagebox.showinfo(title="Error", message=ask_target_class)
                    else:
                        model_path = self.model_name_path
                        confidence_threshold = float(self.threshold.get())
                        ort_session = ort.InferenceSession(model_path)
                        input_name = ort_session.get_inputs()[0].name
                        input_shape = ort_session.get_inputs()[0].shape

                        camera = Picamera2()
                        if self.rotation.get() == "180":
                            camera.configure(camera.create_preview_configuration(transform=libcamera.Transform(hflip=True, vflip=True), main={"size": (4056,3040)}, sensor={'output_size': (4056,3040)})) #"size": (1024,768) for low resolution
                        elif self.rotation.get() == "0":
                            camera.configure(camera.create_preview_configuration(transform=libcamera.Transform(hflip=False, vflip=False), main={"size": (4056,3040)}, sensor={'output_size': (4056,3040)})) #"size": (1024,768) for low resolution
                        camera.set_controls({"AeEnable": False})
                        camera.set_controls({"Brightness": float(self.brightness.get()), "Contrast": float(self.contrast.get()), "Saturation": float(self.saturation.get()), "AnalogueGain": 1, "ExposureTime": int(self.exposure.get())})
                        camera.start()

                        try: #extract input dimensiosn from the onnx model directly
                            model_height = int(input_shape[2])
                            model_width = int(input_shape[3])
                        except (ValueError, TypeError):
                            model_height, model_width = 640, 640
                            print(f"No input dimensions detected. {model_width}x{model_height} used by default")

                        model_metadata = ort_session.get_modelmeta().custom_metadata_map
                        class_names_list = []
                        if 'names' in model_metadata: #extract class names list from the onnx model directly
                            try:
                                extracted_names = ast.literal_eval(model_metadata['names'])
                                if isinstance(extracted_names, dict):
                                    class_names_list = [extracted_names[k] for k in sorted(extracted_names.keys())]
                                elif isinstance(extracted_names, list):
                                    class_names_list = extracted_names
                                print(class_names_list)
                            except Exception as e:
                                print(f"Metadata read error: {e}. Using default ids instead")
                        else:
                            print("No 'names' property found inside the ONNX metadata. Using default ids instead")
                        target_class = ask_target_class
                        saving_time_cooldown = 10.0
                        last_save_time = 0.0
                        live_saving_folder = f"{self.savingfolder_path}/RaCAM_OD_output/Live_detection/{self.corename.get()}/{self.samplename.get()}"
                        if not os.path.exists(live_saving_folder):
                            os.makedirs(live_saving_folder)                        
                        live_window_name = "RaCAM Live Object Detection. Click 'X' or press 'q' key to quit."
                        cv2.namedWindow(live_window_name, cv2.WINDOW_GUI_NORMAL)
                        cv2.resizeWindow(live_window_name, 1024, 768)
                        try:
                            while True:
                                frame = camera.capture_array()
                                orig_h, orig_w = frame.shape[:2]
                                if len(frame.shape) == 3 and frame.shape == 4:
                                    frame = frame[:, :, :3]
                                    frame_bgr = cv2.cvtColor(frame, cv2.COLOR_RGBA2BGR)
                                else:
                                    frame_bgr = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
                                frame_gray = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2GRAY)
                                resized_gray = cv2.resize(frame_gray, (model_width, model_height))
                                three_channel_gray = cv2.merge([resized_gray, resized_gray, resized_gray])
                                input_data = three_channel_gray.astype(np.float32) / 255.0
                                input_data = np.transpose(input_data, (2, 0, 1))
                                input_data = np.expand_dims(input_data, axis=0)
                                outputs = ort_session.run(None, {input_name: input_data})
                                display_frame = cv2.cvtColor(frame_gray, cv2.COLOR_GRAY2BGR)
                                predictions = np.squeeze(outputs) 
                                
                                if predictions.shape[0] < predictions.shape[1]:
                                    predictions = predictions.T
                                boxes = []
                                confidences = []
                                class_ids = []
                                for pred in predictions:
                                    if len(pred) > 5:
                                        x_center, y_center, box_w, box_h = pred[:4]
                                        if len(pred) == 6:
                                            score = pred[4]
                                            class_id = int(pred[5])
                                        else:
                                            class_scores = pred[4:]
                                            class_id = np.argmax(class_scores)
                                            score = class_scores[class_id]
                                    else:
                                        continue
                                    if score < confidence_threshold:
                                        continue
                                    if x_center <= 1.0 and y_center <= 1.0:
                                        x_center *= model_width
                                        y_center *= model_height
                                        box_w *= model_width
                                        box_h *= model_height
                                    x_min = int(x_center - (box_w / 2))
                                    y_min = int(y_center - (box_h / 2))
                                    x = int((x_min / model_width) * orig_w)
                                    y = int((y_min / model_height) * orig_h)
                                    w = int((box_w / model_width) * orig_w)
                                    h = int((box_h / model_height) * orig_h)
                                    boxes.append([x, y, w, h])
                                    confidences.append(float(score))
                                    class_ids.append(int(class_id))

                                indices = cv2.dnn.NMSBoxes(boxes, confidences, confidence_threshold, 0.4)
                                target_detected_this_frame = False
                                if len(indices) > 0:
                                    for i in indices.flatten():
                                        x, y, w, h = boxes[i]
                                        score = confidences[i]
                                        cid = class_ids[i]
                                        x, y = max(0, x), max(0, y)
                                        w, h = min(orig_w - x, w), min(orig_h - y, h)
                                        if cid < len(class_names_list):
                                            name = class_names_list[cid]
                                        else:
                                            name = f"Unknown ({cid})"
                                        np.random.seed(int(cid))
                                        color = tuple(int(c) for c in np.random.randint(0, 255, size=3))
                                        label = f"{name}: {score:.2f}"
                                        cv2.rectangle(display_frame, (x, y), (x + w, y + h), color, 8) #Adjust the following line to change box line thickness and label font sze
                                        (text_width, text_height), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 2.0, 4)
                                        cv2.rectangle(display_frame, (x, y - text_height - 20), (x + text_width, y), color, -1)
                                        cv2.putText(display_frame, label, (x, y - 5), cv2.FONT_HERSHEY_SIMPLEX, 2.0, (255, 255, 255), 4, cv2.LINE_AA)
                                        if name == target_class:
                                            target_detected_this_frame = True

                                if target_detected_this_frame:
                                    current_time = time.time()
                                    if (current_time - last_save_time) > saving_time_cooldown:
                                        timestamp = time.strftime("%Y%m%d-%H%M%S")
                                        filename = f"{self.corename.get()}-{self.samplename.get()}-{self.magnification.get()}-{target_class}-{timestamp}.jpg" #Modify here to change name of saved target live image
                                        full_save_path = os.path.join(live_saving_folder, filename)
                                        cv2.imwrite(full_save_path, display_frame)                                    
                                        last_save_time = current_time

                                cv2.imshow(live_window_name, display_frame)
                                key = cv2.waitKey(1) & 0xFF
                                try:
                                    window_prop = cv2.getWindowProperty(live_window_name, cv2.WND_PROP_VISIBLE)
                                except cv2.error:
                                    window_prop = -1
                                if key == ord('q') or window_prop < 1:
                                    break

                        except KeyboardInterrupt:
                            print("Stopping live detection.")
                        finally:
                            print("Releasing camera hardware for next task...")
                            camera.stop()
                            camera.close()
                            cv2.destroyAllWindows()
                            time.sleep(1.0)
                            print("Camera sensor ready for next task.")

            if self.imageacquisition.get() == "yes":
                subprocess.run(["rpicam-hello", "-t", "0", "--preview", "100,100,1024,768", "--rotation", self.rotation.get(), "--saturation", self.saturation.get(), "--contrast", self.contrast.get(), "--gain", "1", "--brightness", self.brightness.get(), "--shutter", self.exposure.get()])

        if self.imagerecognition.get() == "yes" and self.imageacquisition.get() == "no":
            self.livecolourbutton.config(state="normal", text="Live detection")
        else:
            self.livecolourbutton.config(state="normal", text="Live preview")
        self.snapcolourbutton.config(state="normal")
        self.batchbutton.config(state="normal")
        self.censusbutton.config(state="normal")
        

    def show_messagesnap(self):
        self.livecolourbutton.config(state="disabled")
        self.livecolourbutton.update()
        self.snapcolourbutton.config(state="disabled", text="Processing...")
        self.snapcolourbutton.update()
        self.batchbutton.config(state="disabled")
        self.batchbutton.update()
        self.censusbutton.config(state="disabled")
        self.censusbutton.update()
        
        if self.imageacquisition.get() == "no":
            messagebox.showinfo(title="Error", message="Image acquisition is set on 'no'")
            
        elif self.imageacquisition.get() == "yes":
            if self.imagerecognition.get() == "no":
                fovaddress = f"{self.savingfolder_path}/RaCAM_OD_output/Image_acquisition/{self.corename.get()}/{self.samplename.get()}/"
                if not os.path.isdir(fovaddress):
                    os.makedirs(fovaddress)
                counter = 0
                fovaddressfile = f"{self.savingfolder_path}/RaCAM_OD_output/Image_acquisition/{self.corename.get()}/{self.samplename.get()}/{self.corename.get()}-{self.samplename.get()}-{self.magnification.get()}-{counter}.jpg"
                while os.path.exists(fovaddressfile):
                    counter = counter + 1
                    fovaddressfile = f"{self.savingfolder_path}/RaCAM_OD_output/Image_acquisition/{self.corename.get()}/{self.samplename.get()}/{self.corename.get()}-{self.samplename.get()}-{self.magnification.get()}-{counter}.jpg"
                subprocess.run(["rpicam-still", "--rotation", self.rotation.get(), "--saturation", self.saturation.get(), "--contrast", self.contrast.get(), "--gain", "1", "--brightness", self.brightness.get(), "--shutter", self.exposure.get(), "-q", self.quality.get(), "-f", "-o", fovaddressfile])
                if self.saturation.get() == "0": ## this to remove conversion to 8bit image (divise size by 10)
                    img = Image.open(fovaddressfile) ## this to remove conversion to 8bit image (divise size by 10)
                    img_8bit = img.convert('L')  ## this to remove conversion to 8bit image (divise size by 10)
                    img_8bit.save(fovaddressfile) ## this to remove conversion to 8bit image (divise size by 10)
                #messagebox.showinfo(title="Task completed", message="Image acquisition successfully completed.")

            elif self.imagerecognition.get() == "yes":
                if self.model_name == "No .onnx model selected":
                    messagebox.showinfo(title="Error", message="No .onnx model was selected. Please select an .onnx model file.")
                else:
                    fovaddress = f"{self.savingfolder_path}/RaCAM_OD_output/Image_acquisition/{self.corename.get()}/{self.samplename.get()}/"
                    if not os.path.isdir(fovaddress):
                        os.makedirs(fovaddress)
                    counter = 0
                    fovaddressfile = f"{self.savingfolder_path}/RaCAM_OD_output/Image_acquisition/{self.corename.get()}/{self.samplename.get()}/{self.corename.get()}-{self.samplename.get()}-{self.magnification.get()}-{counter}.jpg"
                    while os.path.exists(fovaddressfile):
                        counter = counter + 1
                        fovaddressfile = f"{self.savingfolder_path}/RaCAM_OD_output/Image_acquisition/{self.corename.get()}/{self.samplename.get()}/{self.corename.get()}-{self.samplename.get()}-{self.magnification.get()}-{counter}.jpg"
                    subprocess.run(["rpicam-still", "--rotation", self.rotation.get(), "--saturation", self.saturation.get(), "--contrast", self.contrast.get(), "--gain", "1", "--brightness", self.brightness.get(), "--shutter", self.exposure.get(), "-q", self.quality.get(), "-f", "-o", fovaddressfile])
                    if self.saturation.get() == "0": ## this to remove conversion to 8bit image (divise size by 10)
                        img = Image.open(fovaddressfile) ## this to remove conversion to 8bit image (divise size by 10)
                        img_8bit = img.convert('L')  ## this to remove conversion to 8bit image (divise size by 10)
                        img_8bit.save(fovaddressfile) ## this to remove conversion to 8bit image (divise size by 10)
                    
                    annotatedaddress = f"{self.savingfolder_path}/RaCAM_OD_output/Image_recognition/{self.corename.get()}/{self.samplename.get()}/"
                    standardFOVname =  f"{self.corename.get()}-{self.samplename.get()}-{self.magnification.get()}-{counter}"
                    standardFOVnamejpg = f"{standardFOVname}.jpg"
                    annotatedFOV = f"{self.corename.get()}-{self.samplename.get()}-{self.magnification.get()}-{counter}-annotated.jpg"
                    fullannotatedaddress = f"{annotatedaddress}{annotatedFOV}"
                    if not os.path.isdir(annotatedaddress):
                        os.makedirs(annotatedaddress)
                    censusaddress = f"{self.savingfolder_path}/RaCAM_OD_output/Raw_census_data/{self.corename.get()}/{self.samplename.get()}/"
                    if not os.path.isdir(censusaddress):
                        os.makedirs(censusaddress)
                    onnx_model = YOLO(self.model_name_path, task='detect')
                    
                    class_list = [onnx_model.names[i] for i in sorted(onnx_model.names.keys())]
                    onnx_session_for_imgsz = ort.InferenceSession(self.model_name_path)
                    input_shape_model = onnx_session_for_imgsz.get_inputs()[0].shape
                    imgsz_extracted = int(input_shape_model[3:][0])
                    
                    inferenceFOV = onnx_model(fovaddressfile, imgsz=imgsz_extracted, conf=float(self.threshold.get()))
                    inferenceFOV[0].save(fullannotatedaddress)
                    if self.imageFOV.get() == "yes":
                        subprocess.run(["xdg-open", fullannotatedaddress])
                        
                    detected_indices = inferenceFOV[0].boxes.cls.tolist()
                    detected_ints = [int(idx) for idx in detected_indices]
                    detected_classes = [onnx_model.names[idx] for idx in detected_ints]
                    row_counts = [str(detected_classes.count(cls)) for cls in class_list]

                    output_txt_file = f"{censusaddress}{standardFOVname}.txt"
                    with open(output_txt_file, "w", encoding="utf-8") as f:
                        f.write("Core name" + "," + "Sample name" + "," + "Original image name" + "," + ",".join(class_list) + "\n")
                        f.write(self.corename.get() + "," + self.samplename.get() + "," + standardFOVnamejpg + "," + ",".join(row_counts) + "\n")
                    #messagebox.showinfo(title="Task completed", message="Image acquisition and object detection successfully completed.")

        self.livecolourbutton.config(state="normal")
        self.snapcolourbutton.config(state="normal", text="Snapshot")
        self.batchbutton.config(state="normal")
        self.censusbutton.config(state="normal")
                        

MyGUI()