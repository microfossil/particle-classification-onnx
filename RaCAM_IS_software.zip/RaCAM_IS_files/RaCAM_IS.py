#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Nov  6 21:27:11 2025

@author: Martin Tetard
"""

import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
from tkinter import filedialog
from tkinter import simpledialog
from PIL import ImageTk, Image
import subprocess
import os
import shutil
import csv

class MyGUI:

    def __init__(self):
        
        def choose_saving_folder():
            self.savingfolder_path = filedialog.askdirectory(title="Select a folder")
            if self.savingfolder_path:
                self.savingfolder.config(text=self.savingfolder_path)
            else:
                self.savingfolder_path = "/home/{username}/Desktop"
                self.savingfolder.config(text=self.savingfolder_path)


        def choose_script():
            self.script_name_path = filedialog.askopenfilename(title="Select an ImageJ script file")
            if self.script_name_path:
                self.script_name = self.script_name_path.split("/")[-1]
                self.script_button.config(text=self.script_name)
            else:
                self.script_name = "No script selected"
                self.script_button.config(text=self.script_name)
                
                
        def choose_model():
            self.model_name_path = filedialog.askopenfilename(title="Select a network_info.xml file")
            if self.model_name_path:
                self.model_name = self.model_name_path.split("/")[-1]
                self.model_button.config(text=self.model_name)
            else:
                self.model_name = "No network_info.xml selected"
                self.model_button.config(text=self.model_name)


        script_folder = os.path.dirname(os.path.abspath(__file__))
        username_folder = f"{script_folder}/.user"
        username_file = f"{username_folder}/user_name.txt"
        if os.path.exists(username_file):
            with open(username_file, "r") as file:
                username = file.read().strip()
        else:
            if os.path.exists(username_folder):
                username = simpledialog.askstring(title="Username Required", prompt="What is your <user> name? (/home/<user>/Desktop). You only have to fill this once:")
                with open(username_file, "w") as file:
                    file.write(username)
            else:
                username = simpledialog.askstring(title="Username Required", prompt="What is your <user> name? (/home/<user>/Desktop). You only have to fill this once:")
                os.mkdir(username_folder)
                with open(username_file, "w") as file:
                    file.write(username)

        self.root = tk.Tk()
        self.root.resizable(False, False)

        policecolour = "#f0eded"
        backgroundcolour = "#43404a"
        backgroundboxcolour = "#bfbfbf"
        buttoncolour = backgroundcolour
        activebuttoncolour = "#1c1c1c"
        buttonpolice = "#fa3e3e"
        activebuttonpolice = "#ff2929"

        self.root.configure(bg=backgroundcolour)

        style= ttk.Style()
        style.configure("TCombobox", fieldbackground= "#bfbfbf", background= "#bfbfbf")

        self.menubar = tk.Menu(self.root, bg=backgroundcolour, fg=policecolour, activebackground=activebuttoncolour, activeforeground=policecolour)

        self.filemenu = tk.Menu(self.menubar, tearoff=0)
        self.filemenu.add_command(label="Image acquisition", command=self.show_messageacquisition)
        self.filemenu.add_command(label="Image segmentation", command=self.show_messageprocessing)
        self.filemenu.add_command(label="Object recognition", command=self.show_messagerecognition)
        self.filemenu.add_command(label="Saving folder", command=self.show_messagesaving)
        self.filemenu.add_command(label="ImageJ script", command=self.show_messagescript)
        self.filemenu.add_command(label="CNN model", command=self.show_messagemodel)
        self.filemenu.add_command(label="Core name", command=self.show_messagecore)
        self.filemenu.add_command(label="Sample name", command=self.show_messagesample)
        self.filemenu.add_command(label="Magnification", command=self.show_messagemagnification)
        self.filemenu.add_command(label="Brightness", command=self.show_messagebrightness)
        self.filemenu.add_command(label="Constrast", command=self.show_messagecontrast)
        self.filemenu.add_command(label="Exposure time", command=self.show_messageexposure)
        self.filemenu.add_command(label="Image rotation", command=self.show_messagerotation)
        self.filemenu.add_command(label="Original image quality", command=self.show_messagequality)
        self.filemenu.add_command(label="Image type", command=self.show_messagesaturation)
        self.filemenu.add_command(label="Image object quality", command=self.show_messageobjectquality)
        self.filemenu.add_command(label="Minimum object size filter", command=self.show_messagesizefilter)
        self.filemenu.add_command(label="CNN threshold", command=self.show_messagethreshold)
        self.filemenu.add_command(label="Live preview", command=self.show_messageliveinfo)
        self.filemenu.add_command(label="Snapshot", command=self.show_messagesnapinfo)
        self.filemenu.add_command(label="Batch processing", command=self.show_messagebatch)
        self.filemenu.add_command(label="Generate census data", command=self.show_messagecensus)

        self.filemenu2 = tk.Menu(self.menubar, tearoff=0)
        self.filemenu2.add_command(label="Software", command=self.show_messagesoftware)
        self.filemenu2.add_command(label="Developers", command=self.show_messagedev)

        self.menubar.add_cascade(menu=self.filemenu, label="Instructions")
        self.menubar.add_cascade(menu=self.filemenu2, label="About")

        self.root.config(menu=self.menubar)

        WindowWidth = 660
        WindowHeight = 700

        self.root.geometry(f"{WindowWidth}x{WindowHeight}")

        self.root.title("RaCAM")

        self.firstframe = tk.Frame(self.root)
        self.firstframe.configure(bg=backgroundcolour)
        self.firstframe.columnconfigure(0, weight=1)
        self.firstframe.columnconfigure(1, weight=1)

        self.esnzlogo = Image.open(f"/home/{username}/Desktop/RaCAM_IS_files/.logo/ESNZlogo.png")
        self.esnzlogo = ImageTk.PhotoImage(self.esnzlogo)
        
        self.racamlogo = Image.open(f"/home/{username}/Desktop/RaCAM_IS_files/.logo/LogoRaCAMIS.png")
        self.racamlogo = ImageTk.PhotoImage(self.racamlogo)

        self.label = tk.Label(self.firstframe, text="RaCAM_IS software v3.7: Image segmentation workflow", font=('Arial', 18), bg=backgroundcolour, fg=policecolour)
        self.label.grid(row=0, column=0, columnspan=2)
        
        #self.label = tk.Label(self.firstframe, text="Image segmentation workflow", font=('Arial', 18), bg=backgroundcolour, fg=policecolour)
        #self.label.grid(row=1, column=0, columnspan=1)
        
        self.labelracam = tk.Label(self.firstframe, image=self.racamlogo, bg=backgroundcolour)
        self.labelracam.grid(row=1, column=0, sticky="w", padx=10, pady=10)

        self.labelesnz = tk.Label(self.firstframe, image=self.esnzlogo, bg=backgroundcolour)
        self.labelesnz.grid(row=1, column=1, sticky="e", padx=10, pady=10)

        self.firstframe.pack(fill='x')


        self.boxframe = tk.Frame(self.root)
        self.boxframe.configure(bg=backgroundcolour)
        self.boxframe.columnconfigure(0, weight=1)
        self.boxframe.columnconfigure(1, weight=1)
        self.boxframe.columnconfigure(2, weight=1)
        
        self.imageacquisitionlabel = tk.Label(self.boxframe, text="Image acquisition", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.imageacquisitionlabel.grid(row=0, column=0, sticky=tk.W+tk.E, pady=5)

        self.checkacquisitionframe = tk.Frame(self.boxframe)
        self.checkacquisitionframe.configure(bg=backgroundcolour)
        self.checkacquisitionframe.columnconfigure(0, weight=1)
        self.checkacquisitionframe.columnconfigure(1, weight=1)

        self.imageacquisitiondefault = "yes" #put back on "no"
        self.imageacquisition = tk.StringVar(self.boxframe, self.imageacquisitiondefault)

        self.imageacquisition_variable = tk.IntVar()
        self.imageacquisition_variable.set(1) #put back on "2"

        self.imageacquisitionyes = tk.Radiobutton(self.checkacquisitionframe, text="Yes", selectcolor=backgroundcolour, bg=backgroundcolour, fg=policecolour, activebackground=activebuttoncolour, activeforeground=activebuttonpolice, variable=self.imageacquisition_variable, value=1, command=self.show_messageimageacqyes)
        self.imageacquisitionyes.grid(row=1, column=0, sticky=tk.W+tk.E)

        self.imageacquisitionno = tk.Radiobutton(self.checkacquisitionframe, text="No", selectcolor=backgroundcolour, bg=backgroundcolour, fg=policecolour, activebackground=activebuttoncolour, activeforeground=activebuttonpolice, variable=self.imageacquisition_variable, value=2, command=self.show_messageimageacqno)
        self.imageacquisitionno.grid(row=1, column=1, sticky=tk.W+tk.E)

        self.checkacquisitionframe.grid(row=1, column=0, sticky=tk.W+tk.E)
        
        
        self.imageprocessinglabel = tk.Label(self.boxframe, text="Image segmentation", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.imageprocessinglabel.grid(row=0, column=1, sticky=tk.W+tk.E, pady=5)

        self.checkimageprocessingframe = tk.Frame(self.boxframe)
        self.checkimageprocessingframe.configure(bg=backgroundcolour)
        self.checkimageprocessingframe.columnconfigure(0, weight=1)
        self.checkimageprocessingframe.columnconfigure(1, weight=1)

        self.imageprocessingdefault = "no"
        self.imageprocessing = tk.StringVar(self.boxframe, self.imageprocessingdefault)

        self.imageprocessing_variable = tk.IntVar()
        self.imageprocessing_variable.set(2)

        self.imageprocessingyes = tk.Radiobutton(self.checkimageprocessingframe, text="Yes", selectcolor=backgroundcolour, bg=backgroundcolour, fg=policecolour, activebackground=activebuttoncolour, activeforeground=activebuttonpolice, variable=self.imageprocessing_variable, value=1, command=self.show_messageimageprocyes)
        self.imageprocessingyes.grid(row=1, column=0, sticky=tk.W+tk.E)

        self.imageprocessingno = tk.Radiobutton(self.checkimageprocessingframe, text="No", selectcolor=backgroundcolour, bg=backgroundcolour, fg=policecolour, activebackground=activebuttoncolour, activeforeground=activebuttonpolice, variable=self.imageprocessing_variable, value=2, command=self.show_messageimageprocno)
        self.imageprocessingno.grid(row=1, column=1, sticky=tk.W+tk.E)

        self.checkimageprocessingframe.grid(row=1, column=1, sticky=tk.W+tk.E)


        self.imagerecognitionlabel = tk.Label(self.boxframe, text="Object recognition", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.imagerecognitionlabel.grid(row=0, column=2, sticky=tk.W+tk.E, pady=5)

        self.checkimagerecognitionframe = tk.Frame(self.boxframe)
        self.checkimagerecognitionframe.configure(bg=backgroundcolour)
        self.checkimagerecognitionframe.columnconfigure(0, weight=1)
        self.checkimagerecognitionframe.columnconfigure(1, weight=1)

        self.imagerecognitiondefault = "no"
        self.imagerecognition = tk.StringVar(self.boxframe, self.imagerecognitiondefault)

        self.imagerecognition_variable = tk.IntVar()
        self.imagerecognition_variable.set(2)

        self.imagerecognitionyes = tk.Radiobutton(self.checkimagerecognitionframe, text="Yes", selectcolor=backgroundcolour, bg=backgroundcolour, fg=policecolour, activebackground=activebuttoncolour, activeforeground=activebuttonpolice, variable=self.imagerecognition_variable, value=1, command=self.show_messageimagerecogyes)
        self.imagerecognitionyes.grid(row=1, column=0, sticky=tk.W+tk.E)

        self.imagerecognitionno = tk.Radiobutton(self.checkimagerecognitionframe, text="No", selectcolor=backgroundcolour, bg=backgroundcolour, fg=policecolour, activebackground=activebuttoncolour, activeforeground=activebuttonpolice, variable=self.imagerecognition_variable, value=2, command=self.show_messageimagerecogno)
        self.imagerecognitionno.grid(row=1, column=1, sticky=tk.W+tk.E)

        self.checkimagerecognitionframe.grid(row=1, column=2, sticky=tk.W+tk.E)
        
        
        self.folderlabel = tk.Label(self.boxframe, text="Select saving folder", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.folderlabel.grid(row=2, column=0, sticky=tk.W+tk.E, pady=5)

        self.savingfolder_path = f"/home/{username}/Desktop"
        self.savingfolder = tk.Button(self.boxframe, text=self.savingfolder_path, command=choose_saving_folder, width=1)
        self.savingfolder.grid(row=3, column=0, sticky=tk.W+tk.E)
        
        self.scriptlabel = tk.Label(self.boxframe, text="Select ImageJ script", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.scriptlabel.grid(row=2, column=1, sticky=tk.W+tk.E, pady=5)

        self.script_name = "No script selected"
        self.script_button = tk.Button(self.boxframe, text=self.script_name, command=choose_script, width=1)
        self.script_button.grid(row=3, column=1, sticky=tk.W+tk.E)
        
        self.modellabel = tk.Label(self.boxframe, text="Select CNN model", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.modellabel.grid(row=2, column=2, sticky=tk.W+tk.E, pady=5)

        self.model_name = "No network_info.xml selected"
        self.model_button = tk.Button(self.boxframe, text=self.model_name, command=choose_model, width=1)
        self.model_button.grid(row=3, column=2, sticky=tk.W+tk.E)
        

        self.corenamelabel = tk.Label(self.boxframe, text="Core name", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.corenamelabel.grid(row=4, column=0, sticky=tk.W+tk.E, pady=5)

        self.corenamedefault = tk.StringVar()
        self.corenamedefault.set("Core_name")
        self.corename = tk.Entry(self.boxframe, textvariable=str(self.corenamedefault), bg=backgroundboxcolour)
        self.corename.grid(row=5, column=0, sticky=tk.W+tk.E)

        self.samplenamelabel = tk.Label(self.boxframe, text="Sample name", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.samplenamelabel.grid(row=4, column=1, sticky=tk.W+tk.E, pady=5)

        self.samplenamedefault = tk.StringVar()
        self.samplenamedefault.set("Sample_name")
        self.samplename = tk.Entry(self.boxframe, textvariable=str(self.samplenamedefault), bg=backgroundboxcolour)
        self.samplename.grid(row=5, column=1, sticky=tk.W+tk.E)

        self.magnificationlabel = tk.Label(self.boxframe, text="Magnification", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.magnificationlabel.grid(row=4, column=2, sticky=tk.W+tk.E, pady=5)

        self.magnificationlist = ["x2.5", "x5", "x10", "x20", "x40", "x63", "x100"]
        self.magnification = ttk.Combobox(self.boxframe, values=self.magnificationlist)
        self.magnification.set("x10")
        self.magnification.grid(row=5, column=2, sticky=tk.W+tk.E)


        self.brightnesslabel = tk.Label(self.boxframe, text="Brightness", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.brightnesslabel.grid(row=6, column=0, sticky=tk.W+tk.E, pady=5)
        
        self.brightnessdefault = tk.IntVar()
        self.brightnessdefault.set(0.05)
        self.brightness = tk.Entry(self.boxframe, textvariable=str(self.brightnessdefault), bg=backgroundboxcolour)
        self.brightness.grid(row=7, column=0, sticky=tk.W+tk.E)
        

        self.contrastlabel = tk.Label(self.boxframe, text="Contrast", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.contrastlabel.grid(row=6, column=1, sticky=tk.W+tk.E, pady=5)

        self.contrastdefault = tk.IntVar()
        self.contrastdefault.set(1.30)
        self.contrast = tk.Entry(self.boxframe, textvariable=str(self.contrastdefault), bg=backgroundboxcolour)
        self.contrast.grid(row=7, column=1, sticky=tk.W+tk.E)

        self.exposurelabel = tk.Label(self.boxframe, text="Exposure time", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.exposurelabel.grid(row=6, column=2, sticky=tk.W+tk.E, pady=5)

        self.exposuredefault = tk.IntVar()
        self.exposuredefault.set(500)
        self.exposure = tk.Entry(self.boxframe, textvariable=str(self.exposuredefault), bg=backgroundboxcolour)
        self.exposure.grid(row=7, column=2, sticky=tk.W+tk.E)


        self.rotationlabel = tk.Label(self.boxframe, text="Image rotation", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.rotationlabel.grid(row=8, column=0, sticky=tk.W+tk.E, pady=5)

        self.rotationlist = ["0", "180"]
        self.rotation = ttk.Combobox(self.boxframe, values=self.rotationlist)
        self.rotation.set(180)
        self.rotation.grid(row=9, column=0, sticky=tk.W+tk.E)

        self.qualitylabel = tk.Label(self.boxframe, text="Original image quality", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.qualitylabel.grid(row=8, column=1, sticky=tk.W+tk.E, pady=5)

        self.qualitydefault = tk.IntVar()
        self.qualitydefault.set(100)
        self.quality = tk.Entry(self.boxframe, textvariable=str(self.qualitydefault), bg=backgroundboxcolour)
        self.quality.grid(row=9, column=1, sticky=tk.W+tk.E)

        self.saturationlabel = tk.Label(self.boxframe, text="Image type", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.saturationlabel.grid(row=8, column=2, sticky=tk.W+tk.E, pady=5)

        self.checkframe = tk.Frame(self.boxframe)
        self.checkframe.configure(bg=backgroundcolour)
        self.checkframe.columnconfigure(0, weight=1)
        self.checkframe.columnconfigure(1, weight=1)

        self.saturationdefault = "0"
        self.saturation = tk.StringVar(self.boxframe, self.saturationdefault)

        self.imagetype_variable = tk.IntVar()
        self.imagetype_variable.set(1)

        self.checkbw = tk.Radiobutton(self.checkframe, text="Greyscale", selectcolor=backgroundcolour, bg=backgroundcolour, fg=policecolour, activebackground=activebuttoncolour, activeforeground=activebuttonpolice, variable=self.imagetype_variable, value=1, command=self.show_messagebw)
        self.checkbw.grid(row=1, column=0, sticky=tk.W+tk.E)

        self.checkcolour = tk.Radiobutton(self.checkframe, text="Colour", selectcolor=backgroundcolour, bg=backgroundcolour, fg=policecolour, activebackground=activebuttoncolour, activeforeground=activebuttonpolice, variable=self.imagetype_variable, value=2, command=self.show_messagecolour)
        self.checkcolour.grid(row=1, column=1, sticky=tk.W+tk.E)

        self.checkframe.grid(row=9, column=2, sticky=tk.W+tk.E)
        

        self.qualityviglabel = tk.Label(self.boxframe, text="Image object quality", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.qualityviglabel.grid(row=10, column=0, sticky=tk.W+tk.E, pady=5)

        self.qualityvigdefault = tk.IntVar()
        self.qualityvigdefault.set(90)
        self.qualityvig = tk.Entry(self.boxframe, textvariable=str(self.qualityvigdefault), bg=backgroundboxcolour)
        self.qualityvig.grid(row=11, column=0, sticky=tk.W+tk.E)

        self.filtersizelabel = tk.Label(self.boxframe, text="Min. object size filter", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.filtersizelabel.grid(row=10, column=1, sticky=tk.W+tk.E, pady=5)

        self.filtersizedefault = tk.StringVar()
        self.filtersizedefault.set("Script default")
        self.filtersize = tk.Entry(self.boxframe, textvariable=str(self.filtersizedefault), bg=backgroundboxcolour)
        self.filtersize.grid(row=11, column=1, sticky=tk.W+tk.E)

        self.thresholdlabel = tk.Label(self.boxframe, text="CNN threshold", font=('Arial', 14), bg=backgroundcolour, fg=policecolour)
        self.thresholdlabel.grid(row=10, column=2, sticky=tk.W+tk.E, pady=5)

        self.thresholddefault = tk.IntVar()
        self.thresholddefault.set(0.30)
        self.threshold = tk.Entry(self.boxframe, textvariable=str(self.thresholddefault), bg=backgroundboxcolour)
        self.threshold.grid(row=11, column=2, sticky=tk.W+tk.E)

        self.boxframe.pack(fill='x')


        self.buttonframe = tk.Frame(self.root)
        self.buttonframe.configure(bg=backgroundcolour)
        self.buttonframe.columnconfigure(0, weight=1)
        self.buttonframe.columnconfigure(1, weight=1)
        ButtonWidth = int(WindowWidth/2)

        self.livecolourbutton = tk.Button(self.buttonframe, text="Live preview", font=('Arial', 20, 'bold') , bg=buttoncolour, fg=buttonpolice, activebackground=activebuttoncolour, activeforeground=activebuttonpolice, width=ButtonWidth, command=self.show_messagelive)
        self.livecolourbutton.grid(row=0, column=0, sticky=tk.W+tk.E)

        self.snapcolourbutton = tk.Button(self.buttonframe, text="Snapshot", font=('Arial', 20, 'bold'),  bg=buttoncolour, fg=buttonpolice, activebackground=activebuttoncolour, activeforeground=activebuttonpolice, width=ButtonWidth, command=self.show_messagesnap)
        self.snapcolourbutton.grid(row=0, column=1, sticky=tk.W+tk.E)

        self.batchbutton = tk.Button(self.buttonframe, text="Batch processing", font=('Arial', 16, 'bold') , bg=buttoncolour, fg=buttonpolice, activebackground=activebuttoncolour, activeforeground=activebuttonpolice, width=ButtonWidth, command=self.batch_processing)
        self.batchbutton.grid(row=1, column=0, sticky=tk.W+tk.E)

        self.censusbutton = tk.Button(self.buttonframe, text="Census data", font=('Arial', 16, 'bold') , bg=buttoncolour, fg=buttonpolice, activebackground=activebuttoncolour, activeforeground=activebuttonpolice, width=ButtonWidth, command=self.generate_image_count_csv)
        self.censusbutton.grid(row=1, column=1, sticky=tk.W+tk.E)

        self.buttonframe.pack(fill='x', pady=15)


        self.savebutton = tk.Button(text="Save profile", font=('Arial', 8) , bg=buttoncolour, fg=policecolour, activebackground=activebuttoncolour, activeforeground=policecolour, width=6, command=self.save_profile)
        self.savebutton.pack(side="left", anchor="s", pady=5)
        self.loadbutton = tk.Button(text="Load profile", font=('Arial', 8) , bg=buttoncolour, fg=policecolour, activebackground=activebuttoncolour, activeforeground=policecolour, width=6, command=self.load_profile)
        self.loadbutton.pack(side="left", anchor="s", padx=0, pady=5)

        self.cclogo = Image.open(f"/home/{username}/Desktop/RaCAM_IS_files/.logo/License.png")
        self.cclogo = ImageTk.PhotoImage(self.cclogo)
        self.labelcc = tk.Label(self.root, image=self.cclogo, bg=backgroundcolour)
        self.labelcc.pack(side="right", anchor="s")

        self.credit = tk.Label(self.root, text="This software was developed by Martin Tetard and Earth Sciences New Zealand", font=('Arial', 8), bg=backgroundcolour, fg=policecolour)
        self.credit.pack(side="right", anchor="s")

        self.root.mainloop()


    def show_messageimageacqyes(self):
        self.imageacquisitiondefault = "yes"
        self.imageacquisition = tk.StringVar(self.boxframe, self.imageacquisitiondefault)


    def show_messageimageacqno(self):
        self.imageacquisitiondefault = "no"
        self.imageacquisition = tk.StringVar(self.boxframe, self.imageacquisitiondefault)


    def show_messageimageprocyes(self):
        self.imageprocessingdefault = "yes"
        self.imageprocessing = tk.StringVar(self.boxframe, self.imageprocessingdefault)


    def show_messageimageprocno(self):
        self.imageprocessingdefault = "no"
        self.imageprocessing = tk.StringVar(self.boxframe, self.imageprocessingdefault)


    def show_messageimagerecogyes(self):
        self.imagerecognitiondefault = "yes"
        self.imagerecognition = tk.StringVar(self.boxframe, self.imagerecognitiondefault)


    def show_messageimagerecogno(self):
        self.imagerecognitiondefault = "no"
        self.imagerecognition = tk.StringVar(self.boxframe, self.imagerecognitiondefault)


    def show_messagebw(self):
        self.saturationdefault = "0"
        self.saturation = tk.StringVar(self.boxframe, self.saturationdefault)


    def show_messagecolour(self):
        self.saturationdefault = "1"
        self.saturation = tk.StringVar(self.boxframe, self.saturationdefault)


    def show_messagedev(self):
        messagebox.showinfo(title="About the developers", message="This software has been developed by Martin Tetard at ESNZ (Earth Sciences New Zealand).")


    def show_messagesoftware(self):
        messagebox.showinfo(title="About the software", message="RaCAM_IS software is a free software (developed using the Python programming language), used to perform image acquisition (using rpicam-apps developed by ((C) Raspberry Pi Ltd), image processing and segmentation (using the ImageJ software) and image recognition using CNNs. Copyright (C) 2026 Martin Tetard. This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version. This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. You should have received a copy of the GNU General Public License along with this program (see gpl-3.0.text in the License directory). If not, see https://www.gnu.org/licenses/.")


    def show_messagecore(self):
        messagebox.showinfo(title="Core name information", message="Enter the core identification value, without '"'-'"' or '"'#'"' symbols.")


    def show_messagesample(self):
        messagebox.showinfo(title="Sample name information", message="Enter the sample identification value, without '"'-'"' or '"'#'"' symbols.")


    def show_messagemagnification(self):
        messagebox.showinfo(title="Magnification information", message="Enter the lens magnification vaue used, for example 'x40'.")


    def show_messagebrightness(self):
        messagebox.showinfo(title="Adjust brightness", message="Adjust the image brightness correction value from -1.0 (completely black image), to 1.0 (completely white image). ")


    def show_messagecontrast(self):
        messagebox.showinfo(title="Adjust contrast", message="Adjust the contrast value of the previewed and captured images. Values above 1.0 increase the contrast, and values below 1.0 decrease it.")


    def show_messageexposure(self):
        messagebox.showinfo(title="Adjust exposure time", message="Adjust the sensor exposure time in ms. A higher value allows for more light to come into the camera sensor and increases the image brightness.")


    def show_messagerotation(self):
        messagebox.showinfo(title="Adjust image rotation", message="Adjust the image rotation from 0 degrees to 180  degrees (depending on the camera's orientation).")


    def show_messagequality(self):
        messagebox.showinfo(title="Adjust image quality", message="Adjust the jpeg image quality value in %, from 0 (more compression, more artifacts, less quality) to 100 (no compression, no artifact, best quality, but bigger size on disk).")


    def show_messagesaturation(self):
        messagebox.showinfo(title="Select image type", message="Select image type between greyscale and full colour.")


    def show_messagesaving(self):
        messagebox.showinfo(title="Select a saving folder", message="Select a saving folder path where all images will be saved.")


    def show_messageacquisition(self):
        messagebox.showinfo(title="Image acquisition", message="Choose if you automatically want to acquire original FOV images.")


    def show_messageprocessing(self):
        messagebox.showinfo(title="Image processing", message="Choose if you automatically want to process (segment) the original acquired FOV images using an ImageJ script.")


    def show_messagerecognition(self):
        messagebox.showinfo(title="Image recognition", message="Choose if you automatically want to identify the segmented image objects using a pre-trained and loaded CNN on a remote computer (check procedure).")


    def show_messagescript(self):
        messagebox.showinfo(title="Select an ImageJ script", message="Select a path to an ImageJ script for automated image processing (scripts are located in /home/{username}/.imagej/macros).")


    def show_messageobjectquality(self):
        messagebox.showinfo(title="Adjust image object quality", message="Adjust the jpeg image object (vignette) quality value in %, from 0 (more compression, more artifacts, less quality) to 100 (no compression, no artifact, best quality, but bigger size on disk).")


    def show_messagesizefilter(self):
        messagebox.showinfo(title="Adjust minimum object size filter", message="Adjust the minimum size of particles (in px²) below which specimens of interest will be excluded.")


    def show_messagemodel(self):
        messagebox.showinfo(title="Select CNN onnx model", message="Select a network_info.xml file located in the same folder as the onnx model you want to use for automated recognition.")


    def show_messagethreshold(self):
        messagebox.showinfo(title="Adjust CNN onnx model threshold", message="Adjust the confidence threshold from 0 to 1 under which an object won't be classified.")


    def show_messageliveinfo(self):
        messagebox.showinfo(title="Livefeed preview", message="Shows a preview of the livefeed currently displayed in the camera's field of view by using the adjusment entered in the textboxes")


    def show_messagesnapinfo(self):
        messagebox.showinfo(title="Taking a snapshot", message="Takes and save a snapshot of the camera's field of view by using the adjusment entered into the textboxes. This button will display a fullscreen preview of the camera's field of view for 5 sec for final depth of field adjustment before saving the image in the /RaCAM_IS_output/Image_acquisition/ directory located on the Desktop.")


    def show_messagebatch(self):
        messagebox.showinfo(title="Batch processing of existing images", message="Click to automatically batch processing existing folders of images. Select a 'core' directory containing 'samples' subdirectories, containing images (by default in /RaCAM_IS_output/Image_acquisition/ or /RaCAM_IS_output/Image_processing/ depending on the wanted task).")


    def show_messagecensus(self):
        messagebox.showinfo(title="Generating a census data csv file", message="Click to generate a census data table containing the abundance of each taxa for each sample of each core. Select and enter a 'core' directory containing 'samples' subdirectories, containing individual object images in /RaCAM_IS_output/Image_recognition/.")


    def save_profile(self):
        saveprofile = open(f"{self.savingfolder_path}/RaCAM_IS_files/.user/profile.txt","w")
        profile_lst = [self.corename.get(),self.samplename.get(),self.magnification.get(),self.brightness.get(),self.contrast.get(),self.exposure.get(),self.rotation.get(),self.quality.get(),self.qualityvig.get(),self.filtersize.get(),self.threshold.get()]
        saveprofile.write(str(profile_lst))
        saveprofile.close
        
                
    def load_profile(self):
        loadprofile = open(f"{self.savingfolder_path}/RaCAM_IS_files/.user/profile.txt","r")
        loadprofile_list = eval(loadprofile.read())
        loadprofile.close()
        self.corenamedefault.set(loadprofile_list[0])
        self.samplenamedefault.set(loadprofile_list[1])
        self.magnification.set(loadprofile_list[2])
        self.brightnessdefault.set(loadprofile_list[3])
        self.contrastdefault.set(loadprofile_list[4])
        self.exposuredefault.set(loadprofile_list[5])
        self.rotation.set(loadprofile_list[6])
        self.qualitydefault.set(loadprofile_list[7])
        self.qualityvigdefault.set(loadprofile_list[8])
        self.filtersizedefault.set(loadprofile_list[9])
        self.thresholddefault.set(loadprofile_list[10])


    def batch_processing(self):
        self.livecolourbutton.config(state="disabled")
        self.livecolourbutton.update()
        self.snapcolourbutton.config(state="disabled")
        self.snapcolourbutton.update()
        self.batchbutton.config(state="disabled", text="Processing...")
        self.batchbutton.update()
        self.censusbutton.config(state="disabled")
        self.censusbutton.update()
        
        if self.imageacquisition.get() == "yes":
            messagebox.showinfo(title="Error", message="Image acquisition is set on 'yes'")
            
        elif self.imageacquisition.get() == "no":
            if self.imageprocessing.get() == "no":
                if self.imagerecognition.get() == "no":
                    messagebox.showinfo(title="Error", message="No task assigned!")
                elif self.imagerecognition.get() == "yes":
                    if self.script_name == "No network_info.xml selected":
                        messagebox.showinfo(title="Error", message="No network_info.xml was selected. Please select a network_info.xml file associated with an onnx model.")
                    else:
                        sharedaddress = f"{self.savingfolder_path}/RaCAM_IS_output/Temp/"
                        if not os.path.isdir(sharedaddress):
                            messagebox.showinfo(title="Error", message="No object images in the '/RaCAM_IS_output/Temp' directory to be labelled.")
                        else:
                            env_name = "miso-onnx"
                            csv_path = f"{sharedaddress}predictions.csv"
                            command_to_run = ["miso-onnx", "classify", "--network-info", self.model_name_path, "--images", sharedaddress, "--batch-size", "16", "--output-csv", csv_path]
                            full_command = ["/home/esnz/miniconda3/bin/conda", "run", "-n", env_name] + command_to_run
                            subprocess.run(full_command, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

                            with open(csv_path, mode='r', newline='', encoding='utf-8') as csv_file:
                                csv_reader = csv.DictReader(csv_file)
                                for row in csv_reader:
                                    srcpath = row["path"]
                                    label = row["label"]
                                    processedimagename = os.path.basename(srcpath)
                                    labelpathlist = processedimagename.split("-")
                                    dstpath = f"{self.savingfolder_path}/RaCAM_IS_output/Image_recognition/{labelpathlist[0]}/{labelpathlist[1]}/{label}/"
                                    if not os.path.isdir(dstpath):
                                        os.makedirs(dstpath)
                                    dstimage = f"{dstpath}{label}-{processedimagename}"
                                    shutil.move(srcpath, dstimage)
                            #shutil.rmtree(sharedaddress)
                            messagebox.showinfo(title="Task completed", message="Image recognition successfully completed.")
            
            elif self.imageprocessing.get() == "yes":
                if self.script_name == "No script selected":
                    messagebox.showinfo(title="Error", message="No ImageJ script was selected. Please select a .ijm script in /home/{username}/.imagej/macros")
                else:
                    if self.imagerecognition.get() == "no":
                        testrecog = "yes"
                        sharedaddress = f"{self.savingfolder_path}/RaCAM_IS_output/Temp/"
                        if not os.path.isdir(sharedaddress):
                            os.makedirs(sharedaddress)
                        vignetteaddress = f"{self.savingfolder_path}/RaCAM_IS_output/Image_processing/"
                        if not os.path.isdir(vignetteaddress):
                            os.makedirs(vignetteaddress)
                        processfolder_path = filedialog.askdirectory(title="Select a core folder containing samples and FOV images")
                        with os.scandir(processfolder_path) as samples_dirs:
                            for sample_dir in samples_dirs:
                                sample_batch = os.path.basename(sample_dir)
                                with os.scandir(sample_dir) as FOVs_dirs:
                                    for FOV_dir in FOVs_dirs:
                                        FOV_batch = os.path.basename(FOV_dir)
                                        fovaddressfile = f"{processfolder_path}/{sample_batch}/{FOV_batch}"
                                        subprocess.run(["imagej", "-m", self.script_name_path, fovaddressfile+"#"+vignetteaddress+"#"+self.filtersize.get()+"#"+self.qualityvig.get()+"#"+testrecog+"#"+sharedaddress])                    
                        messagebox.showinfo(title="Task completed", message="Image processing successfully completed.")

                    elif self.imagerecognition.get() == "yes":
                        if self.script_name == "No network_info.xml selected":
                            messagebox.showinfo(title="Error", message="No network_info.xml was selected. Please select a network_info.xml file associated with an onnx model.")
                        else:
                            testrecog = "yes"
                            sharedaddress = f"{self.savingfolder_path}/RaCAM_IS_output/Temp/"
                            if not os.path.isdir(sharedaddress):
                                os.makedirs(sharedaddress)
                            vignetteaddress = f"{self.savingfolder_path}/RaCAM_IS_output/Image_processing/"
                            if not os.path.isdir(vignetteaddress):
                                os.makedirs(vignetteaddress)
                            processfolder_path = filedialog.askdirectory(title="Select a core folder containing samples and FOV images")
                            with os.scandir(processfolder_path) as samples_dirs:
                                for sample_dir in samples_dirs:
                                    sample_batch = os.path.basename(sample_dir)
                                    with os.scandir(sample_dir) as FOVs_dirs:
                                        for FOV_dir in FOVs_dirs:
                                            FOV_batch = os.path.basename(FOV_dir)
                                            fovaddressfile = f"{processfolder_path}/{sample_batch}/{FOV_batch}"
                                            subprocess.run(["imagej", "-m", self.script_name_path, fovaddressfile+"#"+vignetteaddress+"#"+self.filtersize.get()+"#"+self.qualityvig.get()+"#"+testrecog+"#"+sharedaddress])

                            env_name = "miso-onnx"
                            csv_path = f"{sharedaddress}predictions.csv"
                            command_to_run = ["miso-onnx", "classify", "--network-info", self.model_name_path, "--images", sharedaddress, "--batch-size", "16", "--output-csv", csv_path]
                            full_command = ["/home/esnz/miniconda3/bin/conda", "run", "-n", env_name] + command_to_run
                            subprocess.run(full_command, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                            
                            with open(csv_path, mode='r', newline='', encoding='utf-8') as csv_file:
                                csv_reader = csv.DictReader(csv_file)
                                for row in csv_reader:
                                    srcpath = row["path"]
                                    label = row["label"]
                                    processedimagename = os.path.basename(srcpath)
                                    labelpathlist = processedimagename.split("-")
                                    dstpath = f"{self.savingfolder_path}/RaCAM_IS_output/Image_recognition/{labelpathlist[0]}/{labelpathlist[1]}/{label}/"
                                    if not os.path.isdir(dstpath):
                                        os.makedirs(dstpath)
                                    dstimage = f"{dstpath}{label}-{processedimagename}"
                                    shutil.move(srcpath, dstimage)
                            #shutil.rmtree(sharedaddress)
                            messagebox.showinfo(title="Batch processing", message="Image processing and recognition successfully completed.")

        self.livecolourbutton.config(state="normal")
        self.snapcolourbutton.config(state="normal")
        self.batchbutton.config(state="normal", text="Batch processing")
        self.censusbutton.config(state="normal")


    def generate_image_count_csv(self):
        self.livecolourbutton.config(state="disabled")
        self.livecolourbutton.update()
        self.snapcolourbutton.config(state="disabled")
        self.snapcolourbutton.update()
        self.batchbutton.config(state="disabled")
        self.batchbutton.update()
        self.censusbutton.config(state="disabled", text="Processing...")
        self.censusbutton.update()
        
        self.census_folder_path = filedialog.askdirectory(title="Select a core folder")
        if self.census_folder_path:
            self.census_directory = self.census_folder_path
            self.core_directory = os.path.basename(self.census_directory)
            self.census_ouput = f"{self.census_directory}/{self.core_directory}_Census_counts.csv"
            censusfile = []
            imageextensions = ('.png', '.jpg', '.jpeg', '.gif', '.bmp', '.tiff')
            for dirpath, dirnames, filenames in os.walk(self.census_directory):
                censuscount = sum(1 for filename in filenames if filename.lower().endswith(imageextensions))
                if censuscount > 0:
                    relativefoldername = os.path.relpath(dirpath, self.census_directory)
                    if relativefoldername == '.':
                        foldername = os.path.basename(self.census_directory)
                    else:
                        foldername = relativefoldername
                    pathlist = foldername.split(os.sep)
                    censusfile.append({'Sample name': pathlist[0], 'Label name': pathlist[1], 'Label abundance': censuscount})
            with open(self.census_ouput, mode='w', newline='', encoding='utf-8') as file:
                writer = csv.DictWriter(file, fieldnames=['Sample name', 'Label name', 'Label abundance'])
                writer.writeheader()
                writer.writerows(censusfile)
            messagebox.showinfo(title="Census Data", message="Census data file generation completed.")
        else:
            self.census_folder_path = "No census folder selected"
            messagebox.showinfo(title="Error", message=self.census_folder_path)
            
        self.livecolourbutton.config(state="normal")
        self.snapcolourbutton.config(state="normal")
        self.batchbutton.config(state="normal")
        self.censusbutton.config(state="normal", text="Census data")


    def show_messagelive(self):
        self.livecolourbutton.config(state="disabled", text="Processing...")
        self.livecolourbutton.update()
        self.snapcolourbutton.config(state="disabled")
        self.snapcolourbutton.update()
        self.batchbutton.config(state="disabled")
        self.batchbutton.update()
        self.censusbutton.config(state="disabled")
        self.censusbutton.update()
        
        subprocess.run(["rpicam-hello", "-t", "0", "--preview", "100,100,1024,768", "--rotation", self.rotation.get(), "--saturation", self.saturation.get(), "--contrast", self.contrast.get(), "--gain", "1", "--brightness", self.brightness.get(), "--shutter", self.exposure.get()])
        
        self.livecolourbutton.config(state="normal", text="Livefeed")
        self.snapcolourbutton.config(state="normal")
        self.batchbutton.config(state="normal")
        self.censusbutton.config(state="normal")
        

    def show_messagesnap(self):
        self.livecolourbutton.config(state="disabled")
        self.livecolourbutton.update()
        self.snapcolourbutton.config(state="disabled", text="Processing...")
        self.snapcolourbutton.update()
        self.batchbutton.config(state="disabled")
        self.batchbutton.update()
        self.censusbutton.config(state="disabled")
        self.censusbutton.update()
        
        if self.imageacquisition.get() == "no":
            messagebox.showinfo(title="Error", message="Image acquisition is set on 'no'")
            
        elif self.imageacquisition.get() == "yes":
            if self.imageprocessing.get() == "no":
                fovaddress = f"{self.savingfolder_path}/RaCAM_IS_output/Image_acquisition/{self.corename.get()}/{self.samplename.get()}/"
                if not os.path.isdir(fovaddress):
                    os.makedirs(fovaddress)
                counter = 0
                fovaddressfile = f"{self.savingfolder_path}/RaCAM_IS_output/Image_acquisition/{self.corename.get()}/{self.samplename.get()}/{self.corename.get()}-{self.samplename.get()}-{self.magnification.get()}-{counter}.jpg"
                while os.path.exists(fovaddressfile):
                    counter = counter + 1
                    fovaddressfile = f"{self.savingfolder_path}/RaCAM_IS_output/Image_acquisition/{self.corename.get()}/{self.samplename.get()}/{self.corename.get()}-{self.samplename.get()}-{self.magnification.get()}-{counter}.jpg"
                subprocess.run(["rpicam-still", "--rotation", self.rotation.get(), "--saturation", self.saturation.get(), "--contrast", self.contrast.get(), "--gain", "1", "--brightness", self.brightness.get(), "--shutter", self.exposure.get(), "-q", self.quality.get(), "-f", "-o", fovaddressfile])
                if self.saturation.get() == "0": ## this to remove conversion to 8bit image (divise size by 10)
                    img = Image.open(fovaddressfile) ## this to remove conversion to 8bit image (divise size by 10)
                    img_8bit = img.convert('L') ## this to remove conversion to 8bit image (divise size by 10)
                    img_8bit.save(fovaddressfile) ## this to remove conversion to 8bit image (divise size by 10)
                #messagebox.showinfo(title="Task completed", message="Image acquisition successfully completed.")

            elif self.imageprocessing.get() == "yes":
                if self.script_name == "No script selected":
                    messagebox.showinfo(title="Error", message="No ImageJ script was selected. Please select a .ijm script in /home/{username}/.imagej/macros")
                else:
                    if self.imagerecognition.get() == "no":
                        testrecog = "yes"
                        sharedaddress = f"{self.savingfolder_path}/RaCAM_IS_output/Temp/"
                        if not os.path.isdir(sharedaddress):
                            os.makedirs(sharedaddress)
                        fovaddress = f"{self.savingfolder_path}/RaCAM_IS_output/Image_acquisition/{self.corename.get()}/{self.samplename.get()}/"
                        if not os.path.isdir(fovaddress):
                            os.makedirs(fovaddress)
                        counter = 0
                        fovaddressfile = f"{self.savingfolder_path}/RaCAM_IS_output/Image_acquisition/{self.corename.get()}/{self.samplename.get()}/{self.corename.get()}-{self.samplename.get()}-{self.magnification.get()}-{counter}.jpg"
                        while os.path.exists(fovaddressfile):
                            counter = counter + 1
                            fovaddressfile = f"{self.savingfolder_path}/RaCAM_IS_output/Image_acquisition/{self.corename.get()}/{self.samplename.get()}/{self.corename.get()}-{self.samplename.get()}-{self.magnification.get()}-{counter}.jpg"
                        subprocess.run(["rpicam-still", "--rotation", self.rotation.get(), "--saturation", self.saturation.get(), "--contrast", self.contrast.get(), "--gain", "1", "--brightness", self.brightness.get(), "--shutter", self.exposure.get(), "-q", self.quality.get(), "-f", "-o", fovaddressfile])
                        if self.saturation.get() == "0": ## this to remove conversion to 8bit image (divise size by 10)
                            img = Image.open(fovaddressfile) ## this to remove conversion to 8bit image (divise size by 10)
                            img_8bit = img.convert('L') ## this to remove conversion to 8bit image (divise size by 10)
                            img_8bit.save(fovaddressfile) ## this to remove conversion to 8bit image (divise size by 10)
                        vignetteaddress = f"{self.savingfolder_path}/RaCAM_IS_output/Image_processing/"
                        if not os.path.isdir(vignetteaddress):
                            os.makedirs(vignetteaddress)
                        subprocess.run(["imagej", "-m", self.script_name_path, fovaddressfile+"#"+vignetteaddress+"#"+self.filtersize.get()+"#"+self.qualityvig.get()+"#"+testrecog+"#"+sharedaddress])                    
                        #messagebox.showinfo(title="Task completed", message="Image acquisition and processing successfully completed.")

                    elif self.imagerecognition.get() == "yes":
                        if self.script_name == "No network_info.xml selected":
                            messagebox.showinfo(title="Error", message="No network_info.xml was selected. Please select a network_info.xml file associated with an onnx model.")
                        else:
                            testrecog = "yes"
                            sharedaddress = f"{self.savingfolder_path}/RaCAM_IS_output/Temp/"
                            if not os.path.isdir(sharedaddress):
                                os.makedirs(sharedaddress)
                            labelledaddress = f"{self.savingfolder_path}/RaCAM_IS_output/Image_recognition/{self.corename.get()}/{self.samplename.get()}/"
                            if not os.path.isdir(labelledaddress):
                                os.makedirs(labelledaddress)
                            fovaddress = f"{self.savingfolder_path}/RaCAM_IS_output/Image_acquisition/{self.corename.get()}/{self.samplename.get()}/"
                            if not os.path.isdir(fovaddress):
                                os.makedirs(fovaddress)
                            counter = 0
                            fovaddressfile = f"{self.savingfolder_path}/RaCAM_IS_output/Image_acquisition/{self.corename.get()}/{self.samplename.get()}/{self.corename.get()}-{self.samplename.get()}-{self.magnification.get()}-{counter}.jpg"
                            while os.path.exists(fovaddressfile):
                                counter = counter + 1
                                fovaddressfile = f"{self.savingfolder_path}/RaCAM_IS_output/Image_acquisition/{self.corename.get()}/{self.samplename.get()}/{self.corename.get()}-{self.samplename.get()}-{self.magnification.get()}-{counter}.jpg"
                            subprocess.run(["rpicam-still", "--rotation", self.rotation.get(), "--saturation", self.saturation.get(), "--contrast", self.contrast.get(), "--gain", "1", "--brightness", self.brightness.get(), "--shutter", self.exposure.get(), "-q", self.quality.get(), "-f", "-o", fovaddressfile])
                            if self.saturation.get() == "0": ## this to remove conversion to 8bit image (divise size by 10)
                                img = Image.open(fovaddressfile) ## this to remove conversion to 8bit image (divise size by 10)
                                img_8bit = img.convert('L') ## this to remove conversion to 8bit image (divise size by 10)
                                img_8bit.save(fovaddressfile) ## this to remove conversion to 8bit image (divise size by 10)
                            vignetteaddress = f"{self.savingfolder_path}/RaCAM_IS_output/Image_processing/"
                            if not os.path.isdir(vignetteaddress):
                                os.makedirs(vignetteaddress)
                            subprocess.run(["imagej", "-m", self.script_name_path, fovaddressfile+"#"+vignetteaddress+"#"+self.filtersize.get()+"#"+self.qualityvig.get()+"#"+testrecog+"#"+sharedaddress])
                            
                            env_name = "miso-onnx"
                            csv_path = f"{sharedaddress}predictions.csv"
                            command_to_run = ["miso-onnx", "classify", "--network-info", self.model_name_path, "--images", sharedaddress, "--batch-size", "16", "--output-csv", csv_path]
                            full_command = ["/home/esnz/miniconda3/bin/conda", "run", "-n", env_name] + command_to_run
                            subprocess.run(full_command, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

                            with open(csv_path, mode='r', newline='', encoding='utf-8') as csv_file:
                                csv_reader = csv.DictReader(csv_file)
                                for row in csv_reader:
                                    srcpath = row["path"]
                                    label = row["label"]
                                    processedimagename = os.path.basename(srcpath)
                                    dstpath = f"{labelledaddress}{label}/"
                                    if not os.path.isdir(dstpath):
                                        os.makedirs(dstpath)
                                    dstimage = f"{dstpath}{label}-{processedimagename}"
                                    shutil.move(srcpath, dstimage)
                            #shutil.rmtree(sharedaddress)
                            #messagebox.showinfo(title="Task completed", message="Image acquisition, processing and recognition successfully completed.")

        self.livecolourbutton.config(state="normal")
        self.snapcolourbutton.config(state="normal", text="Snapshot")
        self.batchbutton.config(state="normal")
        self.censusbutton.config(state="normal")
                        

MyGUI()