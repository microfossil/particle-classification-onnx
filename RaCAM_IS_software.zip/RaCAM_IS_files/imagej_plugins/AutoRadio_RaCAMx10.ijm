//Welcome to the AUTOmated SEGMENTER Suit (AutoRadioSegmenter)
//This .ijm plugin was written by Martin Tetard (ESNZ, NZ)

filelist = getArgument();
file = split(filelist,'#');
setBatchMode(true);
                if (endsWith(file[0], ".jpg")){
                        open(file[0]);
                        image_name = getTitle();
                        image_name = replace(image_name, ".jpg", "");
                        rename(image_name);
                        parts = split(image_name, "-");
                        core_name = parts[0];
                        sample_name = parts[1];
                        exmagnification = parts[2];
                        //magnification = parseInt(exmagnification);
                        fovnumber = parts[3];
                        output_core = file[1] + core_name + "/";
                        output_sample = output_core + sample_name + "/";
                        sizefiltre = file[2];
                        if (sizefiltre == "Script default") {
                                sizefiltre = 10000;
                        }
                        vignettequal = file[3];
                        recog = file[4];
                        output_shared = file[5];
                        
                        test0 = File.exists(output_core);

                                if (test0<1){
                                        create_outputcore = File.makeDirectory(output_core);
                                }
                        
                        test1 = File.exists(output_sample);

                                if (test1<1){
                                        create_outputsample = File.makeDirectory(output_sample);
                                }

                        run("Input/Output...", "jpeg="+vignettequal+" gif=-1 file=.csv");
                        run("Options...", "iterations=1 count=1 black pad");
                        run("8-bit");
                        run("Set Scale...", "distance=0 known=0 pixel=1 unit=pixel");
                        setMinAndMax(13, 246);
			run("Apply LUT");
                        run("Duplicate...", "title=processed");
                        
                        selectWindow(image_name);
                        run("Invert");
                        List.setMeasurements;
                        meanbackground = List.getValue("Mode");
                        maxbackground = List.getValue("Max");
                        run("Subtract...", "value="+meanbackground);
                        diff = maxbackground / (maxbackground - meanbackground);
                        run("Multiply...", "value="+diff);

                        selectWindow("processed");
                        run("Set Measurements...", "area mean standard modal bounding shape display redirect=None decimal=3");
                        List.setMeasurements;
                        meanbackground = List.getValue("Mode");
                        meanbackgroundcor = meanbackground - 30;
                        setThreshold(0, meanbackgroundcor);
                        //run("Subtract Background...", "rolling=1000 light sliding disable");
                        //setThreshold(0, 200);
                        setOption("BlackBackground", true);
                        run("Convert to Mask");
                        run("Options...", "iterations=1 count=1 black pad");
                        //run("Close-");
                        run("Fill Holes");
                        run("Gaussian Blur...", "sigma=5");
                        setThreshold(100, 255);
                        run("Convert to Mask");
                        run("Fill Holes");
                        run("Adjustable Watershed", "tolerance=5");
                        //run("Watershed Irregular Features", "erosion=1 convexity_threshold=0.94 separator_size=0-Infinity");
                        //run("Watershed Irregular Features", "erosion=15 convexity_threshold=0.00 separator_size=0-Infinity");
                        run("Analyze Particles...", "size="+sizefiltre+"-Infinity circularity=0.00-1.00 exclude include add");
                        selectWindow("processed");
                        close();

                        for (k = 0; k < roiManager("count"); k++) {         
                                selectWindow(image_name);
                                roiManager("Select", k);
                                run("Enlarge...", "enlarge=2 pixel");
                                run("Copy");
                                List.setMeasurements;
                                WidthSel = List.getValue("Width");
                                HeightSel = List.getValue("Height");
                                        if(WidthSel > HeightSel){
                                                newImage("Squarevig", "8-bit black", WidthSel+6, WidthSel+6, 1);
                                        }
                                        else{
                                                newImage("Squarevig", "8-bit black", HeightSel+6, HeightSel+6, 1);  
                                        }
                                run("Paste");
                                //run("Enlarge...", "enlarge=5 pixel");
                                //run("Duplicate...", "saveout");
                                //run("Clear Outside");
                                seg_number = (k+1);
                                seg_name = image_name+"-"+seg_number;
                                rename(seg_name);
                                saveAs("jpeg", output_sample + seg_name);
                                if (recog=="yes"){
                                        saveAs("jpeg", output_shared + seg_name);
                                }
                                close();
                                }

                        selectWindow(image_name);
                        close();
                        roiManager("Reset");
                        }

run("Input/Output...", "jpeg=100 gif=-1 file=.csv");
run("Quit");